backup before solve:

questions:

1. handle eof

2. pAboutWriteFile->sFileAddress vs pSession->pLocalFileAddress
3. pAboutWriteFile->pOpenWriteType vs aDefaultOpenWriteType
//especially before : sendTheRequestFile, receiveTheRequestFile

solution: 
save in pSession->sLocalFileAddress
assign to pAbout....->pFileAddress when openRead/WriteFile.

#include "/media/NOW/ET2440_TCPIP/sftp/sftp.h"

string sDefaultLocalFilename[] = "rfc867_sr.txt";
char aDefaultLocalFileAddress[] = "/media/NOW/ET2440_TCPIP/sftp/rfc867_sr.txt";
string sDefaultCurrentPath = "/media/NOW/ET2440_TCPIP/tftp/";

///temp test code
//int tSizeDefaultFile = 2519; //only client
///temp test code end


void handleDeadChildProcess()
{
	while(waitpid(-1, NULL, WNOHANG) > 0);
    printf("\nok: one child-connection finished.\n");
    printf("\nok: waiting for connections...\n");
}
int prepareToHandleDeadChildProcess()//The code that's there is responsible for reaping zombie processes that appear as the fork()ed child processes exit. If you make lots of zombies and don't reap them, your system administrator will become agitated.
{
    struct sigaction tSigaction;

	tSigaction.sa_handler = (void(*)(int))handleDeadChildProcess; //reap all dead processes
	sigemptyset(&tSigaction.sa_mask);
	tSigaction.sa_flags = SA_RESTART;
	if (sigaction(SIGCHLD,
                  &tSigaction,/*struct sigaction sa*/
                  NULL
                 ) == -1)
    {
		perror("ERR: sigaction");
		exit(1);
	}

    debug("ok: prepareToHandleDeadChildProcess().");
    return 0;
}

int initialize()
{
    debug("ok: initialize().start.");

    newStruct();

    pSession->cClientOrServer = 's';
    pSession->sCurrentPath = sDefaultCurrentPath;
    pSession->readyForSubcommand = 0;

    pSession->requestQueueMax = 10;
    pSession->pLocalPort = (char*)"5570";//sftp
    pSession->pLocalFileAddress = aDefaultLocalFileAddress;

    debug("ok: initialize().end.");
    return 0;
}

int getaddrinfoLocal()
{
    debug("ok: getaddrinfoLocal().start.");
    int getaddrinfoStatus;

    memset(&pSession->getaddrinfoSourceLinkList, 0, sizeof pSession->getaddrinfoSourceLinkList);
    pSession->getaddrinfoSourceLinkList.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
    pSession->getaddrinfoSourceLinkList.ai_socktype = SOCK_STREAM;
    pSession->getaddrinfoSourceLinkList.ai_flags = AI_PASSIVE; // use my IP
    pSession->reusable = 1;

	if ((getaddrinfoStatus = getaddrinfo(NULL,
                                        pSession->pLocalPort,
                                        &pSession->getaddrinfoSourceLinkList,
                                        &pSession->pGetaddrinfoResultLinkList
                                        )
        ) != 0)
	{
		fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(getaddrinfoStatus));
		return 1;
	}

    debug("ok: getaddrinfo().end.");
    return 0;
}
int tryCreateSocketReusableAndBind()
{
    debug("ok: tryCreateSocketReusableAndBind().start.");

    struct addrinfo *piTempAddrinfo;
    piTempAddrinfo = pSession->pGetaddrinfoResultLinkList;

    if (piTempAddrinfo == NULL)
	{
		fprintf(stderr, "ERR:  pGetaddrinfoResultLinkList is NULL, cannot try to creat and bind.\n");
		return 2;
	}

    for( ; piTempAddrinfo != NULL; piTempAddrinfo = piTempAddrinfo->ai_next)
	{
	    ///creat
		if ((pSession->localListener = socket(piTempAddrinfo->ai_family,
                                            piTempAddrinfo->ai_socktype,
                                            piTempAddrinfo->ai_protocol
                                            )
            ) == -1)
        {
			perror("ERR: server: socket");
			continue;
		}
		debug("ok: socket().");

        ///set to reusable
		if (setsockopt(pSession->localListener,  //socket descriptor
                       SOL_SOCKET,     //Socket Option Level: set will happen at the  level of SOCKET
                       SO_REUSEADDR,   //The socket option for which the value is to be set
                       &pSession->reusable,//A pointer to the buffer in which the value for the requested option is specified. //int reusable = 1; /*#define SOL_SOCKET 1; #define SO_REUSEADDR	2*/
                       sizeof(int)
                       )== -1)
        {//reusable, in case of unexpected exit
			perror("ERR: setsockopt, couldn't set to reusable.");
			exit(1);
		}
        debug("ok: setsockopt, reusable. ");

        ///bind
		if (bind(pSession->localListener,
                piTempAddrinfo->ai_addr,
                piTempAddrinfo->ai_addrlen
                ) == -1)
		{
			close(pSession->localListener);
			perror("ERR: server: bind");
			continue;
		}
        debug("ok: bind.");

        ///all done
		break;
	}

    debug("ok: tryCreateSocketReusableAndBind().end.");
    return 0;
}
int tryListen()
{
    debug("ok: tryListen().start.");

	if (listen(pSession->localListener,
                pSession->requestQueueMax
                ) == -1)
	{
		perror("ERR: listen");
		exit(1);
	}

    debug("ok: tryListen().end.");
    return 0;
}
int tryAccept()
{
    pSession->sizeRemoteAddressInformation = sizeof pSession->remoteAddressInformation;
    pSession->localSocket = accept(pSession->localListener,
                                    (struct sockaddr *)&pSession->remoteAddressInformation,
                                    &pSession->sizeRemoteAddressInformation
                                    );

    if (pSession->localSocket == -1)
    {
        perror("ERR: accept");
        return 1;
    }
    else
    {
        debug("ok: accept().");
    }

    //inet_ntop: convert IPv4 or IPv6 addresses from binary to text string form
    inet_ntop(pSession->remoteAddressInformation.ss_family,
              getBinaryIp( (struct sockaddr *) &pSession->remoteAddressInformation ),
              pSession->aIpRemote,
              sizeof pSession->aIpRemote
             );
    printf("ok: got connection from: %s, %s.\n\n", pSession->aIpRemote,timeStamp());//char ipRemote[INET6_ADDRSTRLEN];

    return 0;
}

int dealWithAConnection()
{
    debug("ok: childProcess().start.");
    pSession->sessionClosed = 0;

    close(pSession->localListener); // child doesn't need the listener
    debug("ok: childProcess(). close(localListener).");

    while(1)//each loop for each command
    {
        pHandleSftpPacket->sExpectedPacketType = "commandPacket";

        unpackTcpPacket();// may set pSession->sessionClosed = 1
        if(pSession->sessionClosed)
        {
            break;
        }
        unpackSftpPacket();

        printf("\nok: finished command: \"%s\".%s.\n\n",pSftpCommandPacket->aCommand,timeStamp());
    }

    pSession->sessionClosed = 0;

    close(pSession->localSocket);
    debug("ok: child: close(localSocket).");

    exit(0);
}

int main(void)
{
    initialize();

    getaddrinfoLocal();
    tryCreateSocketReusableAndBind();
	freeaddrinfo(pSession->pGetaddrinfoResultLinkList); // all done with this structure
    debug("ok: freeaddrinfo().");

    tryListen();

    prepareToHandleDeadChildProcess();

	say("\nok: waiting for connections...\n");

	while(1) //each loop for each connection
	{
        if ( tryAccept() == 1 ) //if ERR: accept
        {
            continue;
        }

		if (fork()==0) //success, fork() return 0 to child and return child's PID to parent.
		{
            dealWithAConnection();
		}
        else //if in parent instead of child process
        {
            close(pSession->localSocket);
            debug("ok: parent: close(localSocket), parent doesn't need.");
        }
	}

	return 0;
}//int main(void)


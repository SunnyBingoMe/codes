#ifndef SFTP_H_INCLUDED
#define SFTP_H_INCLUDED

#include <algorithm> //transform string up/low
#include <arpa/inet.h>//inet_net_ntop...
#include <errno.h>
#include <netdb.h>//getaddrinfo...
#include <netinet/in.h>//Standard well-defined IP protocols
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>//fcn waitpid
#include <sys/wait.h> //fcn waitpid; 3rd parameter of fcn waitpid;

char aDefaultOpenReadType[] = "rb";
char aDefaultOpenWriteType[] = "wb";
///temp test code
int tSizeDefaultFile = 2519;
///temp test code end

#include "/media/NOW/codes/frequentFunction.h"
#include "/media/NOW/ET2440_TCPIP/sftp/sftpStruct.h"
#include "/media/NOW/ET2440_TCPIP/sftp/sftpFunctionDeclaration.h"

int openReadFile()
{
    struct stat tStat;
    if ( (pAboutReadFile->pReadFile = fopen(pAboutReadFile->pFilename, pAboutReadFile->pOpenReadType)) == NULL)
    {
        printf("ERR: openReadFile(): fopen(), pFilename:%s.\n",pAboutReadFile->pFilename);
        exit(1);
    }
    stat(pAboutReadFile->pFilename, &tStat);
    pAboutReadFile->sizeFile = tStat.st_size;

    debug("ok: openReadFile().");
    return 0;
}
int closeReadFile()
{
    fclose(pAboutReadFile->pReadFile);
    return 0;
}
int openWriteFile()
{
    if ( (pAboutWriteFile->pWriteFile = fopen(pAboutWriteFile->pFilename, pAboutWriteFile->pOpenWriteType)) == NULL)
    {
        printf("ERR: openWriteFile(): fopen(), pFilename:%s.\n",pAboutWriteFile->pFilename);
        return 1;
    }

    return 0;
}
int closeWriteFile()
{
    fclose(pAboutWriteFile->pWriteFile);
    return 0;
}
int readBinaryDataFromFile()
{
    debug("ok: readBinaryDataFromFile().start.");
    int iFread = 0;
    char readTempChar;

    pAboutReadFile->sizeReadUnit = sizeof(char);
    while( fread(&readTempChar,pAboutReadFile->sizeReadUnit,1, pAboutReadFile->pReadFile), !feof(pAboutReadFile->pReadFile) && !ferror(pAboutReadFile->pReadFile) )
    {
        if(dDbugOk){printf("ok: read %c\n", readTempChar);}
        pAboutReadFile->aReadBuffer[iFread] = readTempChar;
        if(dDbugOk){printf("ok: iFread and aReadBuffer[iFread]:%d,%c.\n",iFread,pAboutReadFile->aReadBuffer[iFread]);}
        iFread ++;
        if(iFread == maxReadOnce)
        {
            break;
        }
    }
    if (feof(pAboutReadFile->pReadFile))
    {
        pPrepareSftpDataPacket->reachEofSend = 1;
        if(dbug){printf("ok: feof(), iFread(last read):%dbytes.\n",iFread);}
//            aReadBuffer[iFread] = '\0';
    }
    if (ferror(pAboutReadFile->pReadFile))
    {
        printf("ERR: read file.\n");
        return 1;
    }

    pAboutReadFile->sizeReadData = iFread;
    if (dbug){printf("ok: read:%d bytes.\n",pAboutReadFile->sizeReadData);}

    if (dDbugOk){printf("ok: aReadBuffer:%s.\n",pAboutReadFile->aReadBuffer);}

    debug("ok: readBinaryDataFromFile().end.");
    return 0;
}
int writeBinaryDataToFile()
{
    debug("ok: writeBinaryDataToFile().start.");
    int tSizeDataHasWritten;

    pAboutWriteFile->sizeWriteUnit = sizeof(char);
    tSizeDataHasWritten = fwrite(pAboutWriteFile->pWriteBuffer, pAboutWriteFile->sizeWriteUnit, pAboutWriteFile->sizeWriteData, pAboutWriteFile->pWriteFile);
    if(tSizeDataHasWritten != pAboutWriteFile->sizeWriteData)
    {
        printf("ERR: want write: %d bytes, but written: %d bytes.",pAboutWriteFile->sizeWriteData,tSizeDataHasWritten);
        return 1;
    }
    if(dbug){printf("ok: written: %d bytes.\n",tSizeDataHasWritten);}

    debug("ok: writeBinaryDataToFile().end.");
    return 0;
}
void * getBinaryIp(struct sockaddr * tSockaddr)// get sockaddr, IPv4 or IPv6:
{
    if (tSockaddr->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)tSockaddr)->sin_addr);
    }

    return &(((struct sockaddr_in6*)tSockaddr)->sin6_addr);
}

int newStruct()
{
    debug("ok: newStruct().start.");

    pSession = new session;
    pAboutReadFile = new aboutReadFile;
    pAboutWriteFile = new aboutWriteFile;

    ///send
    pPrepareSftpCommandPacket = new prepareSftpCommandPacket;
    pPrepareSftpDataPacket = new prepareSftpDataPacket;
    pPrepareTcpLoad = new prepareTcpLoad;
    ///send end

    pSftpErrorPacket = new sftpErrorPacket;

    ///receive
    pPrepareSftpCommandPacket->pOriginalAddress = pSftpCommandPacket = new sftpCommandPacket;
    pPrepareSftpDataPacket->pOriginalAddress = pSftpDataPacket = new sftpDataPacket;
    pSftpPacket = new sftpPacket;

    pHandleSftpPacket = new handleSftpPacket;
    pHandleSftpDataPacket = new handleSftpDataPacket;
    pHandleSftpCommandPacket = new handleSftpCommandPacket;
    pHandleTcpLoad = new handleTcpLoad;
    ///receive end

    debug("ok: newStruct().end.");
    return 0;
}

int sendTheRequestFile()
{
    debug("\nok: sendTheRequestFile().start.");

    pAboutReadFile->pFilename = pSession->pLocalFilename;
    pAboutReadFile->pOpenReadType = aDefaultOpenReadType;
    openReadFile();

    pPrepareSftpDataPacket->reachEofSend = 0;

    while(1) //transfer all data of the file
    {
        packSftpDataPacket();
        packTcpPacket();

        if(pPrepareSftpDataPacket->reachEofSend)
        {
            debug("ok: sendTheRequestFile() reach eof.");
            break;
        }

        say("");
    }

    closeReadFile();
    pPrepareSftpDataPacket->reachEofSend = 0;

    debug("\nok: sendTheRequestFile().end.\n");
    return 0;
}

int receiveTheRequestFile()
{
    debug("ok: receiveTheRequestFile().start.");

    pAboutWriteFile->pFilename = pSession->pLocalFilename;
    pAboutWriteFile->pOpenWriteType = aDefaultOpenWriteType;
    openWriteFile();

    ///need change
    pAboutWriteFile->sizeFile = tSizeDefaultFile;
    ///need change end
    pAboutWriteFile->sizePassedFile = 0;
    pHandleSftpDataPacket->reachEofReceive = 0;//?

    debug("\nok: \"while\": receive and write.start.\n");
    while(1) ///the "while" of: receive all the data of remote file and write to local file
    {
        unpackTcpPacket();
        unpackSftpPacket();

        if(pHandleSftpDataPacket->reachEofReceive)//?
        {
            debug("ok: the \"while\" of: receive: reachEofReceive.");
            break;
        }

        debug("");
    }
    debug("\nok: \"while\": receive and write.end.\n");

    closeWriteFile();

    pHandleSftpDataPacket->reachEofReceive = 0;//?

    debug("ok: receiveTheRequestFile().end.");
    return 0;
}

int packSftpCommandPacket()
{
    char tCmd[5];
    debug("ok: packSftpCommandPacket().start.");
    pSftpCommandPacket = pPrepareSftpCommandPacket->pOriginalAddress;
    memset(pSftpCommandPacket,'\0',sizeof(sftpCommandPacket));

    printf("ok: please type in the command:");
    getline(cin,pPrepareSftpCommandPacket->sCommand);
    if(pPrepareSftpCommandPacket->sCommand.length() < 4 || pPrepareSftpCommandPacket->sCommand.length() > tcpLoadMax)
    {
        say("ERR: the length of the command is too short or too long.");
        pPrepareSftpCommandPacket->sCmd.clear();
        pPrepareTcpLoad->sizeTcpLoadToSend = 0;
        return 1;
    }
    memmove(pSftpCommandPacket->aCommand,pPrepareSftpCommandPacket->sCommand.c_str(),pPrepareSftpCommandPacket->sCommand.size());
    pSftpCommandPacket->aCommand[pPrepareSftpCommandPacket->sCommand.size()] = '\0';

    pPrepareTcpLoad->pTcpLoadToSend = pSftpCommandPacket->aCommand;
    pPrepareTcpLoad->sizeTcpLoadToSend = pPrepareSftpCommandPacket->sCommand.size() + 1;

    pPrepareSftpCommandPacket->sCommand.copy(tCmd,4,0);//return int: 4
    tCmd[4] = '\0';
    pPrepareSftpCommandPacket->sCmd = tCmd;
    pPrepareSftpCommandPacket->sCmd = toUpString(pPrepareSftpCommandPacket->sCmd);
    if(dbug)printf("ok: cmd: %s.\n",pPrepareSftpCommandPacket->sCmd.c_str());
    if(pPrepareSftpCommandPacket->sCommand.length() > 5)
    {
        pPrepareSftpCommandPacket->sArgs = (char*)pPrepareSftpCommandPacket->sCommand.c_str() + 5;
        if(dbug)printf("ok: args: %s.\n",pHandleSftpCommandPacket->sArgs.c_str());
    }

    debug("ok: packSftpCommandPacket().end.");
    return 0;
}

int packErrorPacket(string tsErrorContent)
{
    //char * tpErrorContent;
    string tsMinusSign = "-";
    //string tsErrorContent = tpErrorContent;
    string tsErrorMessage = tsMinusSign + tsErrorContent;
    tsErrorMessage.copy(pSftpErrorPacket->aErrorMessage,tsErrorMessage.size());
    pSftpErrorPacket->aErrorMessage[tsErrorMessage.size()] = '\0';

    pPrepareTcpLoad->pTcpLoadToSend = (char*)pSftpErrorPacket;
    pPrepareTcpLoad->sizeTcpLoadToSend = tsErrorMessage.size()+1;
    return 0;
}
int packSftpDataPacket()
{
    debug("ok: packSftpDataPacket().");
    pSftpDataPacket = pPrepareSftpDataPacket->pOriginalAddress;
    memset(pSftpDataPacket,'\0',sizeof(sftpDataPacket));

    readBinaryDataFromFile();

    pPrepareTcpLoad->pTcpLoadToSend = pAboutReadFile->aReadBuffer;
    pPrepareTcpLoad->sizeTcpLoadToSend = pAboutReadFile->sizeReadData;

    debug("ok: packSftpDataPacket().");
    return 0;
}

int packTcpPacket()
{
    if ((send (pSession->localSocket,
                pPrepareTcpLoad->pTcpLoadToSend,
                pPrepareTcpLoad->sizeTcpLoadToSend,
                0
                )
        ) == -1)
    {
        perror("ERR: packTcpPacket(): send()");
    }
    else if(pPrepareTcpLoad->sizeTcpLoadToSend != 0 && dbug)
    {
        printf("ok: packTcpPacket(): sent %d bytes, %s.\n",pPrepareTcpLoad->sizeTcpLoadToSend,timeStamp());
    }
    else if(pPrepareTcpLoad->sizeTcpLoadToSend == 0 && dbug)
    {
        debug("ok: packTcpPacket(). sent none.");
    }

    return 0;
}

int checkNotErrorPacket()
{
    if(pHandleSftpPacket->cFirstCharactor != '-')
    {
        debug("ok: checkNotErrorPacket(): is error packet.");
        return 1;
    }

    debug("ok: checkNotErrorPacket(): isn't error packet.");
    return 0;
}

int unpackTcpPacket()
{
    debug("ok: unpackTcpPacket().start.");
    if(pSession->cClientOrServer == 's')
    {
        say("ok: waiting command...");
    }
    memset(pHandleTcpLoad->aTcpLoadReceiveBuffer,'\0',tcpLoadMax);
    if((pHandleTcpLoad->sizeTcpLoadHasReceive = recv(pSession->localSocket,
                                                    pHandleTcpLoad->aTcpLoadReceiveBuffer,
                                                    tcpLoadMax,//tcpLoadReceiveMax - 1,
                                                    0
                                                    )
        ) == -1 ) // -1: ERR; 0: close; +:count
    {
        perror("ERR: tryReceive():recv()");
        exit(1);
    }
    if (pHandleTcpLoad->sizeTcpLoadHasReceive != -1 && dbug)// receive() is on-line
    {
        pSession->pTextIpRemote = inet_ntop(pSession->remoteAddressInformation.ss_family,
                                            getBinaryIp((struct sockaddr *)&pSession->remoteAddressInformation),
                                            pSession->aIpRemote,
                                            sizeof pSession->aIpRemote
                                            );
        printf("ok: received tcpload %d bytes from %s, %s.\n",pHandleTcpLoad->sizeTcpLoadHasReceive,pSession->aIpRemote,timeStamp());
        if(pHandleTcpLoad->sizeTcpLoadHasReceive <= 20)
        {
            printf("ok: received tcpload content:%s.\n",pHandleTcpLoad->aTcpLoadReceiveBuffer);
        }
    }
    if (pHandleTcpLoad->sizeTcpLoadHasReceive ==  0)// socket closed by remote
    {
        printf("ok: socket closed by remote.\n");
        pSession->sessionClosed = 1;

        if(pSession->cClientOrServer == 'c')
        {
            exit(1);
        }

        return 0;
    }

    debug("ok: unpackTcpPacket().end.");
    return 0;
}

int unpackSftpDataPacket()
{
    debug("ok: unpackSftpDataPacket().start.");
    pSftpDataPacket = (sftpDataPacket*)pHandleTcpLoad->aTcpLoadReceiveBuffer;

    pHandleSftpDataPacket->pBlockDataReceive = pHandleTcpLoad->aTcpLoadReceiveBuffer;
    pHandleSftpDataPacket->sizeBlockDataReceive = pHandleTcpLoad->sizeTcpLoadHasReceive;

    pAboutWriteFile->pWriteBuffer = pHandleSftpDataPacket->pBlockDataReceive;
    pAboutWriteFile->sizeWriteData = pHandleSftpDataPacket->sizeBlockDataReceive;
    writeBinaryDataToFile();

    pAboutWriteFile->sizePassedFile += pAboutWriteFile->sizeWriteData;
    if(pAboutWriteFile->sizePassedFile >= pAboutWriteFile->sizeFile)
    {

        debug("ok: reachEofReceive.");
        pHandleSftpDataPacket->reachEofReceive = 1;
    }

    debug("ok: unpackSftpDataPacket().end.");
    return 0;
}

int unpackSftpPacket()
{
    debug("ok: unpackSftpPacket().start.");
    pSftpPacket = (sftpPacket*)pHandleTcpLoad->aTcpLoadReceiveBuffer;

    pHandleSftpPacket->cFirstCharactor = pSftpPacket->aBlockData[0];

    if(!pHandleSftpPacket->sExpectedPacketType.compare("commandPacket"))
    {
        unpackSftpCommandPacket();
    }
    else if(!pHandleSftpPacket->sExpectedPacketType.compare("dataPacket"))
    {
        unpackSftpDataPacket();
    }
    else
    {
        say("ERR: unknown packet type.");
        return 1;
    }

    debug("ok: unpackSftpPacket().end.");
    return 0;
}

int unpackSftpCommandPacket()
{
    debug("ok: unpackSftpCommandPacket().start.");
    pSftpCommandPacket = (sftpCommandPacket*)pHandleTcpLoad->aTcpLoadReceiveBuffer;
    pHandleSftpCommandPacket->sizeSftpCommandPacket = pHandleTcpLoad->sizeTcpLoadHasReceive;
    printf("\nok: got command: %s.\n\n",pSftpCommandPacket->aCommand);

    char tCmd[5];
    memmove(tCmd, pSftpCommandPacket, 4);
    tCmd[4] = '\0';
    pHandleSftpCommandPacket->sCmd = tCmd;
    pHandleSftpCommandPacket->sCmd = toUpString(pHandleSftpCommandPacket->sCmd);
    if(dbug)printf("ok: cmd: %s.\n",pHandleSftpCommandPacket->sCmd.c_str());

    if(pHandleSftpCommandPacket->sizeSftpCommandPacket > 5)
    {
        pHandleSftpCommandPacket->sArgs = (char*)pSftpCommandPacket + 5;
        if(dbug)printf("ok: args: %s.\n",pHandleSftpCommandPacket->sArgs.c_str());
    }

    ///switch cmd
    if(!pHandleSftpCommandPacket->sCmd.compare("SEND"))
    {
        debug("ok: switch cmd: SEND.");
        sendTheRequestFile();
    }
    else
    {
        say("ERR: unexpected command.");
        packErrorPacket("ERR: server received unexpected command");
        packTcpPacket();
        return 1;
    }

    debug("ok: unpackSftpCommandPacket().end.");
    return 0;
}


#endif // SFTP_H_INCLUDED

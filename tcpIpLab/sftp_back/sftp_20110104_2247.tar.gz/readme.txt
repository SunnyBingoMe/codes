complete cdir.
corret bug:default file size when receive file.
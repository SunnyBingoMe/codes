#ifndef SFTP_H_INCLUDED
#define SFTP_H_INCLUDED

#include "/media/NOW/codes/debugAndalways.h"

#include <errno.h>
#include <string.h>
#include <sys/types.h>//fcn waitpid
#include <sys/socket.h>
#include <netinet/in.h>//Standard well-defined IP protocols
#include <netdb.h>//getaddrinfo...
#include <arpa/inet.h>//inet_net_ntop...
#include <sys/wait.h> //fcn waitpid; 3rd parameter of fcn waitpid;
#include <signal.h>

#define tcpLoadMax 516

struct session
{
    char cClientOrServer;

    char * pRemoteHost;//name or ip //server don't need
    char * pRemotePort;
    char * pLocalPort;
    int requestQueueMax;//clinet don't need
    int reusable;//clinet don't need ?
    struct addrinfo getaddrinfoSourceLinkList;
    struct addrinfo * pGetaddrinfoResultLinkList;
    struct addrinfo * pFirstValidGetaddrinfoSourceLinkListSend;//server don't need
    //struct addrinfo * pFirstValidGetaddrinfoSourceLinkListReceive;

    int localListener;//client don't need
    int localSocket;// listen on localListener, new connection on localSocket

    char * pRemoteFilename;//server don't need
    char * pLocalFilename;
    char cReadOrWrite;
    char * pMode;
    int sizeFile;
    int sizeFilePassed;

    //int requsetOk;
    int sessionClosed;

    struct sockaddr_storage remoteAddressInformation;
    socklen_t sizeRemoteAddressInformation;//unsigned int
    char aIpRemote[INET6_ADDRSTRLEN];
    const char * pTextIpRemote;
};
struct session * pSession;

///read and write file
#define maxReadOnce tcpLoadMax
struct aboutReadFile
{
    char * pFilename;
    char * pOpenReadType;
    char aReadBuffer[maxReadOnce];
    int sizeReadUnit;
    int sizeReadData;
    FILE * pReadFile;
};
struct aboutReadFile * pAboutReadFile;
struct aboutWriteFile
{
    char * pFilename;
    char * pOpenWriteType;
    char * pWriteBuffer;
    int sizeWriteUnit;
    int sizeWriteData;
    FILE * pWriteFile;
};
struct aboutWriteFile * pAboutWriteFile;
///read and write file end

///pack and unpack
#define blockDataMax tcpLoadMax
    ///send
struct prepareSftpCommandPacket
{
    struct sftpCommandPacket * pOriginalAddress;
    string sCommand;
};
struct prepareSftpCommandPacket * pPrepareSftpCommandPacket;

struct prepareSftpDataPacket
{
    struct sftpDataPacket * pOriginalAddress;
    int sizeBlockDataToSend;
    int reachEofSend;
};
struct prepareSftpDataPacket * pPrepareSftpDataPacket;

struct prepareTcpLoad
{
    char * pTcpLoadToSend;
    int sizeTcpLoadToSend;
    int sizeTcpLoadHasSend;//for debug
};
struct prepareTcpLoad * pPrepareTcpLoad;
    ///send end

struct sftpPacket
{
	char aBlockData[blockDataMax];
};
struct sftpPacket * pSftpPacket;
struct sftpDataPacket
{
	char aBlockData[blockDataMax];
};
struct sftpDataPacket * pSftpDataPacket;
struct sftpCommandPacket
{
    char aCommand[tcpLoadMax];
};
struct sftpCommandPacket * pSftpCommandPacket;

    ///receive
struct handleTcpLoad
{
    char aTcpLoadReceiveBuffer[tcpLoadMax];//void * pTcpLoadHasReceive;
    int sizeTcpLoadHasReceive;
};
struct handleTcpLoad * pHandleTcpLoad;
struct handleSftpPacket
{
    int sizeSftpPacket;
    string sExpectedPacketType;
};
struct handleSftpPacket * pHandleSftpPacket;
struct handleSftpCommandPacket
{
    int sizeSftpCommandPacket;
    string sCmd;
    string sArgs;
};
struct handleSftpCommandPacket * pHandleSftpCommandPacket;
struct handleSftpDataPacket
{
    char * pBlockDataReceive;
    int sizeBlockDataReceive;
    int reachEofReceive;
};
struct handleSftpDataPacket * pHandleSftpDataPacket;
    ///receive end

///pack and unpack end

int openReadFile()
{
    if ( (pAboutReadFile->pReadFile = fopen(pAboutReadFile->pFilename, pAboutReadFile->pOpenReadType)) == NULL)
    {
        printf("ERR: openReadFile(): fopen(), pFilename:%s.\n",pAboutReadFile->pFilename);
        exit(1);
    }
    else
    {
        debug("ok: openReadFile().");
    }
    return 0;
}
int closeReadFile()
{
    fclose(pAboutReadFile->pReadFile);
    return 0;
}
int openWriteFile()
{
    if ( (pAboutWriteFile->pWriteFile = fopen(pAboutWriteFile->pFilename, pAboutWriteFile->pOpenWriteType)) == NULL)
    {
        printf("ERR: openWriteFile(): fopen(), pFilename:%s.\n",pAboutWriteFile->pFilename);
        return 1;
    }

    return 0;
}
int closeWriteFile()
{
    fclose(pAboutWriteFile->pWriteFile);
    return 0;
}
int readBinaryDataFromFile()
{
    debug("ok: readBinaryDataFromFile().");
    int iFread = 0;
    char readTempChar;

    pAboutReadFile->sizeReadUnit = sizeof(char);
    while( fread(&readTempChar,pAboutReadFile->sizeReadUnit,1, pAboutReadFile->pReadFile), !feof(pAboutReadFile->pReadFile) && !ferror(pAboutReadFile->pReadFile) )
    {
        if(dDbugOk){printf("ok: read %c\n", readTempChar);}
        pAboutReadFile->aReadBuffer[iFread] = readTempChar;
        if(dDbugOk){printf("ok: iFread and aReadBuffer[iFread]:%d,%c.\n",iFread,pAboutReadFile->aReadBuffer[iFread]);}
        iFread ++;
        if(iFread == maxReadOnce)
        {
            break;
        }
    }
    if (feof(pAboutReadFile->pReadFile))
    {
        pPrepareSftpDataPacket->reachEofSend = 1;
        printf("ok: eof.\n");
        if(dbug){printf("ok: in feof(), iFread(last read):%dbytes.\n",iFread);}
//            aReadBuffer[iFread] = '\0';
    }
    if (ferror(pAboutReadFile->pReadFile))
    {
        printf("ERR: read file.\n");
        return 1;
    }

    pAboutReadFile->sizeReadData = iFread;
    if (dbug){printf("ok: read:%d bytes.\n",pAboutReadFile->sizeReadData);}

    if (dDbugOk){printf("ok: aReadBuffer:%s.\n",pAboutReadFile->aReadBuffer);}

    debug("ok: readBinaryDataFromFile().");
    return 0;
}
int writeBinaryDataToFile()
{
    debug("ok: writeBinaryDataToFile().start.");
    int tSizeDataHasWritten;

    pAboutWriteFile->sizeWriteUnit = sizeof(char);
    tSizeDataHasWritten = fwrite(pAboutWriteFile->pWriteBuffer, pAboutWriteFile->sizeWriteUnit, pAboutWriteFile->sizeWriteData, pAboutWriteFile->pWriteFile);
    if(tSizeDataHasWritten != pAboutWriteFile->sizeWriteData)
    {
        printf("ERR: want write: %d bytes, but written: %d bytes.",pAboutWriteFile->sizeWriteData,tSizeDataHasWritten);
        return 1;
    }
    if(dbug){printf("ok: written: %d bytes.",tSizeDataHasWritten);}

    debug("ok: writeBinaryDataToFile().end.");
    return 0;
}
void * getBinaryIp(struct sockaddr * tSockaddr)// get sockaddr, IPv4 or IPv6:
{
    if (tSockaddr->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)tSockaddr)->sin_addr);
    }

    return &(((struct sockaddr_in6*)tSockaddr)->sin6_addr);
}

int newStruct()
{
    debug("ok: newStruct().start.");

    pSession = new session;
    pAboutReadFile = new aboutReadFile;
    pAboutWriteFile = new aboutWriteFile;

    ///send
    pPrepareSftpCommandPacket = new prepareSftpCommandPacket;
    pPrepareSftpDataPacket = new prepareSftpDataPacket;
    pPrepareTcpLoad = new prepareTcpLoad;
    ///send end

    pPrepareSftpCommandPacket->pOriginalAddress = pSftpCommandPacket = new sftpCommandPacket;
    pPrepareSftpDataPacket->pOriginalAddress = pSftpDataPacket = new sftpDataPacket;

    ///receive
    pSftpPacket = new sftpPacket;

    pHandleSftpPacket = new handleSftpPacket;
    pHandleSftpDataPacket = new handleSftpDataPacket;
    pHandleSftpCommandPacket = new handleSftpCommandPacket;
    pHandleTcpLoad = new handleTcpLoad;
    ///receive end

    debug("ok: newStruct().end.");
    return 0;
}

int packTcpPacket()
{
    if ((send (pSession->localSocket,
                pPrepareTcpLoad->pTcpLoadToSend,
                pPrepareTcpLoad->sizeTcpLoadToSend,
                0
                )
        ) == -1)
    {
        perror("ERR: packTcpPacket(): send()");
    }
    printf("ok: packTcpPacket(): sent %d bytes, %s.\n",pPrepareTcpLoad->sizeTcpLoadToSend,timeStamp());
    return 0;
}

int unpackTcpPacket()
{
    debug("ok: unpackTcpPacket().start.");
    if(pSession->cClientOrServer == 's')
    {
        say("ok: waiting command...");
    }
    memset(pHandleTcpLoad->aTcpLoadReceiveBuffer,'\0',tcpLoadMax);
    if((pHandleTcpLoad->sizeTcpLoadHasReceive = recv(pSession->localSocket,
                                                    pHandleTcpLoad->aTcpLoadReceiveBuffer,
                                                    tcpLoadMax,//tcpLoadReceiveMax - 1,
                                                    0
                                                    )
        ) == -1 ) // -1: ERR; 0: close; +:count
    {
        perror("ERR: tryReceive():recv()");
        exit(1);
    }
    if (pHandleTcpLoad->sizeTcpLoadHasReceive != -1 && dbug)// receive() is on-line
    {
        pSession->pTextIpRemote = inet_ntop(pSession->remoteAddressInformation.ss_family,
                                            getBinaryIp((struct sockaddr *)&pSession->remoteAddressInformation),
                                            pSession->aIpRemote,
                                            sizeof pSession->aIpRemote
                                            );
        printf("ok: received tcpload %d bytes from %s, %s.\n",pHandleTcpLoad->sizeTcpLoadHasReceive,pSession->aIpRemote,timeStamp());
        if(pHandleTcpLoad->sizeTcpLoadHasReceive <= 20)
        {
            printf("ok: received tcpload content:%s.\n",pHandleTcpLoad->aTcpLoadReceiveBuffer);
        }
    }
    if (pHandleTcpLoad->sizeTcpLoadHasReceive ==  0)// socket closed by remote
    {
        printf("ok: socket closed by remote.\n");
        pSession->sessionClosed = 1;
        return 0;
    }

/// need del
    if(pHandleTcpLoad->sizeTcpLoadHasReceive < tcpLoadMax && pSession->cClientOrServer == 'c')//?
    {
        debug("ok: reachEofReceive.");
        pHandleSftpDataPacket->reachEofReceive = 1;
    }
/// need del end

    debug("ok: unpackTcpPacket().end.");
    return 0;
}

int unpackSftpDataPacket()
{
    debug("ok: unpackSftpDataPacket().start.");
    pSftpDataPacket = (sftpDataPacket*)pHandleTcpLoad->aTcpLoadReceiveBuffer;

    pHandleSftpDataPacket->pBlockDataReceive = pHandleTcpLoad->aTcpLoadReceiveBuffer;
    pHandleSftpDataPacket->sizeBlockDataReceive = pHandleTcpLoad->sizeTcpLoadHasReceive;

    pAboutWriteFile->pWriteBuffer = pHandleSftpDataPacket->pBlockDataReceive;
    pAboutWriteFile->sizeWriteData = pHandleSftpDataPacket->sizeBlockDataReceive;
    writeBinaryDataToFile();

    debug("ok: unpackSftpDataPacket().end.");
    return 0;
}

#endif // SFTP_H_INCLUDED

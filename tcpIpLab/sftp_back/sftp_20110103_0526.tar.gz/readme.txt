complete RETR and SEND/STOP.

//something wrong with "openReadFile"????
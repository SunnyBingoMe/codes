#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define SERVERPORT "69"    // the port users will be connecting to
#define MYPORT "59590"

/*
int sOk = 1;
int dbug = 0;
int dbugOk = 0;
int dDbug = 0;
int dDbugOk = 0;
*/
int sOk = 0;
int dbug = 1;
int dbugOk = 0;
int dDbug = 1;
int dDbugOk = 0;

void say (char * string)
{
    printf("%s\n",string);
}
void sayOk (void * string)
{
    if(sOk)
    {
        say (string);
    }
}
void debug (void * string)
{
    if(dbug)
    {
        say (string);
    }
}
void debugOk (void * string)
{
    if(dbugOk)
    {
        say (string);
    }
}
void dDebug (void * string)
{
    if(dDbug)
    {
        say (string);
    }
}
void dDebugOk (void * string)
{
    if(dDbugOk)
    {
        say (string);
    }
}

char * pDefaultRemoteHost = "127.0.0.1";
char * pDefaultRemoteFilename = "/media/NOW/ET2440_TCPIP/tftp/tftp/rfc867_sr.txt";
char * pDefaultLocalFilename = "/media/NOW/ET2440_TCPIP/tftp/tftp_cl/rfc867_cl.txt";
char cDefaultReadRequest = 'r';
char * pDefaultMode = "octet";
char * pDefaultOpenWriteType = "wb";

struct aboutReadFile
{
};
struct aboutReadFile * pAboutReadFile;

struct aboutWriteFile
{
    char * pFilename;
    char * pOpenWriteType;
    char * pWriteBuffer;
    int sizeWriteUnit;
    int sizeWriteData;
    FILE * pWriteFile;
};
struct aboutWriteFile * pAboutWriteFile;

struct session
{
    struct addrinfo getaddrinfoSourceLinkList;
    struct addrinfo * pGetaddrinfoResultLinkList;
    struct addrinfo * pFirstValidGetaddrinfoSourceLinkListSend;
//    struct addrinfo * pFirstValidGetaddrinfoSourceLinkListReceive;
    int localSocket;
    char * pRemoteHost;//name or ip
    char * pRemoteFilename;
    char * pLocalFilename;
    char cReadOrWrite;
    char * pMode;
    struct sockaddr_storage remoteAddressInformation;
    socklen_t sizeRemoteAddressInformation;
    char aIpRemote[INET6_ADDRSTRLEN];
    const char * pTextIpRemote;
};
struct session * pSession;

///pack and unpack

    ///send
struct prepareTftpRequestPacket
{
	unsigned short opcode;
    char * pFilename;
    int sizeFilename;
    char * pMode;
    int sizeMode;
    int sizeWithoutOpcode;
//    int sizeTftpRequestPacket;
};
struct prepareTftpRequestPacket * pPrepareTftpRequestPacket;

#define withoutOpcodeMax 514 //blockNr + 512
struct tftpRequestPacket
{
	unsigned short opcodeNetOrder;
    char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpRequestPacket * pTftpRequestPacket;

struct prepareUdpLoad
{
    void * pUdpLoadToSend;
    int sizeUdpLoadToSend;
    int sizeUdpLoadHasSend;//for debug
};
struct prepareUdpLoad * pPrepareUdpLoad;
    ///send end

    ///receive
#define udpLoadReceiveMax 516
struct handleUdpLoad
{
    char aUdpLoadReceiveBuffer[udpLoadReceiveMax];//void * pUdpLoadHasReceive;
    int sizeUdpLoadHasReceive;
};
struct handleUdpLoad * pHandleUdpLoad;

struct tftpPacket
{
	unsigned short opcodeNetOrder;
	char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpPacket * pTftpPacket;

struct handleTftpPacket
{
    int sizeWithoutOpcode;
    int sizeBlockDataHasReceive;
	unsigned short opcode;
	unsigned short blockNrTftpDataPacket;
};
struct handleTftpPacket * pHandleTftpPacket;

#define blockDataMax 512
struct tftpDataPacket
{
	unsigned short opcodeNetOrder;
	unsigned short blockNrNetOrder;
	char aBlockData[blockDataMax];
};
struct tftpDataPacket * pTftpDataPacket;

struct handleTftpDataPacket
{
    int blockNrTftpDataPacket;
    char * pBlockDataReceive;
    int sizeBlockDataReceive;
    int reachEofReceive;
};
struct handleTftpDataPacket * pHandleTftpDataPacket;

struct tftpAckPacket
{
};
struct tftpAckPacket * pTftpAckPacket;
// struct etc.
    ///receive end
///pack and unpack end


void * getBinaryIp(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

char * timeStamp()
{
    char * stringTimeStamp;
    time_t rawtime;
    time ( &rawtime );
    stringTimeStamp = ctime( (time_t*) &rawtime);
    stringTimeStamp[24] = '\0';
    return stringTimeStamp;
}

int initialize(int argc, char *argv[])
{
    debug("ok: in initialize().");

    pAboutWriteFile = malloc(sizeof(struct aboutWriteFile));
    pAboutReadFile = malloc(sizeof(struct aboutReadFile));

    ///send
    pPrepareTftpRequestPacket = malloc(sizeof(struct prepareTftpRequestPacket));
    pPrepareUdpLoad = malloc(sizeof(struct prepareUdpLoad));
    ///send end

    pTftpRequestPacket = malloc(sizeof(struct tftpRequestPacket));
    pSession = malloc(sizeof(struct session));
    pTftpPacket = malloc(sizeof(struct tftpPacket));
    pTftpDataPacket = malloc(sizeof(struct tftpDataPacket));
    pTftpAckPacket = malloc(sizeof(struct tftpAckPacket));

    ///receive
    pHandleUdpLoad = malloc(sizeof(struct handleUdpLoad));
    pHandleTftpPacket = malloc(sizeof(struct handleTftpPacket));
    pHandleTftpDataPacket = malloc(sizeof(struct handleTftpDataPacket));
    if(dbugOk){printf("ok: malloc: sizeof(struct tftpPacket):%d.\n",sizeof(struct tftpPacket));}
    ///receive end

    memset(&pSession->getaddrinfoSourceLinkList, 0, sizeof pSession->getaddrinfoSourceLinkList);
    pSession->getaddrinfoSourceLinkList.ai_family = AF_UNSPEC;
    pSession->getaddrinfoSourceLinkList.ai_socktype = SOCK_DGRAM;
    //pSession->getaddrinfoSourceLinkList.ai_flags = AI_PASSIVE; //use my IP //code only used in server

    if (argc != 5)
    {
	    printf("OBS! You have not input 1.\"remote host\", 2.\"/remote filename\" and 3.\"/local filename\". Will use default.\n");
        pSession->pRemoteHost = pDefaultRemoteHost;
        pSession->pRemoteFilename = pDefaultRemoteFilename;
        pSession->pLocalFilename = pDefaultLocalFilename;
        pSession->cReadOrWrite = cDefaultReadRequest;
        pSession->pMode = pDefaultMode;
        debug("ok: used default.");
    }
    else
    {
        pSession->pRemoteHost = argv[1];
        pSession->pRemoteFilename = argv[2];
        pSession->pLocalFilename = argv[3];
        pSession->cReadOrWrite = *(argv[4]);//'r' for "read from remote"
        pSession->pMode = pDefaultMode;
    }

    debug("ok: initialize().");
    return 0;
}

int getaddrinfoSend()
{
    int getaddrinfoStatus;
    if ((getaddrinfoStatus = getaddrinfo(pSession->pRemoteHost,// e.g. "www.example.com" or IP
                                          SERVERPORT,// e.g. "http" or port number
                                          &pSession->getaddrinfoSourceLinkList,//did not say use locallopp ip
                                          &pSession->pGetaddrinfoResultLinkList//results: a pointer to a linked-list
                                          )
        ) != 0)
    {
        fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(getaddrinfoStatus));
        return 1;
    }

    debug("ok: getaddrinfoSend().");
	return 0;
}

int createSocketSend()
{
    struct addrinfo * pTempAddrinfo;
    for(pTempAddrinfo = pSession->pGetaddrinfoResultLinkList; pTempAddrinfo != NULL; pTempAddrinfo = pTempAddrinfo->ai_next)
    {
        if ((pSession->localSocket = socket(pTempAddrinfo->ai_family,
                                            pTempAddrinfo->ai_socktype,
                                            pTempAddrinfo->ai_protocol
                                            )
            ) == -1
           )
        {
            perror("ERR: socket(), will try next.");
            continue;
        }
        break;
    }
    if (pTempAddrinfo == NULL)
    {
        fprintf(stderr, "ERR: failed to socket().");
        return 2;
    }
    pSession->pFirstValidGetaddrinfoSourceLinkListSend = pTempAddrinfo;

    debug("ok: createSocketSend().");
	return 0;
}

int getaddrinfoReceive()
{
    int getaddrinfoStatus;
    if ((getaddrinfoStatus = getaddrinfo(pSession->pRemoteHost,
                                          MYPORT,
                                          &pSession->getaddrinfoSourceLinkList,
                                          &pSession->pGetaddrinfoResultLinkList
                                          )
        ) != 0
       )
    {
        fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(getaddrinfoStatus));
        return 1;
    }

    debug("ok: getaddrinfoReceive().");
	return 0;
}

int bindSendSocketAsReceive()
{
    struct addrinfo * pTempAddrinfo;
    for(pTempAddrinfo = pSession->pGetaddrinfoResultLinkList; pTempAddrinfo != NULL; pTempAddrinfo = pTempAddrinfo->ai_next)
    {
        if (bind(pSession->localSocket,
                pTempAddrinfo->ai_addr,
                pTempAddrinfo->ai_addrlen
                ) == -1
            )
        {
            perror("ERR: bind, will try next.");
            continue;
        }

        debug("ok: bind().");
        break;
    }

    if (pTempAddrinfo == NULL)
    {
        fprintf(stderr, "ERR: failed to bind socket\n");
        return 2;
    }
//    pSession->pFirstValidGetaddrinfoSourceLinkListReceive = pTempAddrinfo;

    debug("ok: bindSendSocketAsReceive().");
    return 0;
}

int openWriteFile()
{
    if ( (pAboutWriteFile->pWriteFile = fopen(pAboutWriteFile->pFilename, pAboutWriteFile->pOpenWriteType)) == NULL)
    {
        say("ERR: fopen writeFile.");
        return 1;
    }

    return 0;
}

int prepareSend()
{
    if(pSession->cReadOrWrite == 'r')
    {
    ///pack read_request and re-direct
        memset(pTftpRequestPacket, '\0', sizeof(struct tftpRequestPacket));
        pPrepareTftpRequestPacket->opcode = 1;
        pPrepareTftpRequestPacket->pFilename = pSession->pRemoteFilename;
        pPrepareTftpRequestPacket->sizeFilename = strlen(pSession->pRemoteFilename);
        pPrepareTftpRequestPacket->pMode = pSession->pMode;
        pPrepareTftpRequestPacket->sizeMode = strlen(pSession->pMode);
        pPrepareTftpRequestPacket->sizeWithoutOpcode = pPrepareTftpRequestPacket->sizeFilename + pPrepareTftpRequestPacket->sizeMode + 2;

        pTftpRequestPacket->opcodeNetOrder = htons(pPrepareTftpRequestPacket->opcode);
        memmove(pTftpRequestPacket->aWithoutOpcode, pPrepareTftpRequestPacket->pFilename, pPrepareTftpRequestPacket->sizeFilename);
        memmove(((char*)pTftpRequestPacket->aWithoutOpcode) + pPrepareTftpRequestPacket->sizeFilename + 1, pPrepareTftpRequestPacket->pMode, pPrepareTftpRequestPacket->sizeMode);

        pPrepareUdpLoad->pUdpLoadToSend = (void *)pTftpRequestPacket;
        pPrepareUdpLoad->sizeUdpLoadToSend = 2 + pPrepareTftpRequestPacket->sizeWithoutOpcode;
    ///pack read_request and re-direct end
    }

    debug("ok: prepareSend().");
    return 0;
}

int sendData()
{
    if ((pPrepareUdpLoad->sizeUdpLoadHasSend = sendto(pSession->localSocket,
                                                   pPrepareUdpLoad->pUdpLoadToSend,
                                                   pPrepareUdpLoad->sizeUdpLoadToSend,
                                                   0,
                                                   pSession->pFirstValidGetaddrinfoSourceLinkListSend->ai_addr,
                                                   pSession->pFirstValidGetaddrinfoSourceLinkListSend->ai_addrlen
                                                  )
        ) == -1
       )
    {
        perror("ERR: sendto");
        exit(1);
    }
    if(dDbugOk){printf("ok: send: %dbytes, content:%s.\n",pPrepareUdpLoad->sizeUdpLoadHasSend,(char*)pPrepareUdpLoad->pUdpLoadToSend);}
	if(dbug)
	{
        printf("ok: sent %dbytes udpload to %s\n", pPrepareUdpLoad->sizeUdpLoadHasSend, pSession->pRemoteHost);
	}

    printf("ok: sendData().%s.\n",timeStamp());
    printf("ok: client: waiting packet ...\n");
	return 0;
}

int receiveAndUnpackUdpPacket()
{
    if ((pHandleUdpLoad->sizeUdpLoadHasReceive = recvfrom(pSession->localSocket,
                                                        pHandleUdpLoad->aUdpLoadReceiveBuffer,
                                                        udpLoadReceiveMax,//udpLoadReceiveMax-1,////for end of string
                                                        0,
                                                        (struct sockaddr *)&pSession->remoteAddressInformation,
                                                        &pSession->sizeRemoteAddressInformation
                                                        )
         ) == -1
        )
    {
        perror("recvfrom");
        exit(1);
    }
//    aUdpLoadReceiveBuffer[sizeUdpLoadHasReceive] = '\0';
    if(dbug)
    {
        pSession->pTextIpRemote = inet_ntop(pSession->remoteAddressInformation.ss_family,
                                            getBinaryIp((struct sockaddr *)&pSession->remoteAddressInformation),
                                            pSession->aIpRemote,
                                            sizeof pSession->aIpRemote
                                            );
        printf("ok: got packet from %s\n",pSession->pTextIpRemote);
    }
    if(dDbugOk){printf("ok: recv: %dbytes, %s.\n", pHandleUdpLoad->sizeUdpLoadHasReceive,pHandleUdpLoad->aUdpLoadReceiveBuffer);}
    else{if(dbug)printf("ok: sizeUdpLoadHasReceive:%d.\n",pHandleUdpLoad->sizeUdpLoadHasReceive);}

    printf("ok: receiveAndUnpackUdpPacket().%s.\n",timeStamp());
    return 0;
}

int writeBinaryDataToFile()
{
    debug("ok: in writeBinaryDataToFile().");
//    sizeWriteBuffer = sizeReadBuffer;
    fwrite(pAboutWriteFile->pWriteBuffer, pAboutWriteFile->sizeWriteUnit, pAboutWriteFile->sizeWriteData, pAboutWriteFile->pWriteFile);

    say("ok: writeBinaryDataToFile().");
    return 0;
}
int unpackTftpDataPacket()
{
    debug("ok: packet is data_packet.");
    pTftpDataPacket = (struct tftpDataPacket *) pTftpPacket;
    pHandleTftpDataPacket->blockNrTftpDataPacket = ntohs(pTftpDataPacket->blockNrNetOrder);
    pHandleTftpDataPacket->sizeBlockDataReceive = pHandleTftpPacket->sizeWithoutOpcode - 2;
    pHandleTftpDataPacket->pBlockDataReceive = pTftpDataPacket->aBlockData;
    if(pHandleTftpDataPacket->sizeBlockDataReceive < blockDataMax)
    {
        pHandleTftpDataPacket->reachEofReceive = 1;
    }
    if(dbug){printf("ok: pHandleTftpDataPacket->blockNrTftpDataPacket:%d.\n",pHandleTftpDataPacket->blockNrTftpDataPacket);}

    pAboutWriteFile->pWriteBuffer = pHandleTftpDataPacket->pBlockDataReceive;
    pAboutWriteFile->sizeWriteData = pHandleTftpDataPacket->sizeBlockDataReceive;
    pAboutWriteFile->sizeWriteUnit = sizeof(char);
    if(dbug){printf("ok: sizeWriteData = sizeBlockDataReceive:%d.\n",pAboutWriteFile->sizeWriteData);}
    writeBinaryDataToFile();

    return 0;
}

int unpackTftpPacket()
{
    pTftpPacket = (struct tftpPacket*) pHandleUdpLoad->aUdpLoadReceiveBuffer;

    pHandleTftpDataPacket->reachEofReceive = 0;

    ///unpack and re-direct
    pHandleTftpPacket->sizeWithoutOpcode = pHandleUdpLoad->sizeUdpLoadHasReceive - 2;
    pHandleTftpPacket->opcode = ntohs(pTftpPacket->opcodeNetOrder);
    ///if data, then tftpPacket => dataPacket
    if(pHandleTftpPacket->opcode == 3)
    {
        unpackTftpDataPacket();
    }
    ///unpack and re-direct end

    debug("ok: unpackTftpPacket().");
    return pHandleTftpDataPacket->reachEofReceive;
}

int closeWriteFile()
{
    fclose(pAboutWriteFile->pWriteFile);
    return 0;
}

int main(int argc, char *argv[])
{
    initialize(argc, argv);

    getaddrinfoSend();
    createSocketSend();

    getaddrinfoReceive();
    bindSendSocketAsReceive();
    freeaddrinfo(pSession->pGetaddrinfoResultLinkList);

    pAboutWriteFile->pFilename = pSession->pLocalFilename;
    pAboutWriteFile->pOpenWriteType = pDefaultOpenWriteType;
    openWriteFile();

    prepareSend();
    sendData();
    pSession->sizeRemoteAddressInformation = sizeof pSession->remoteAddressInformation;

    while(1) ///the "while" of: receive the data of remote file and write to local file
    {
        receiveAndUnpackUdpPacket();

        unpackTftpPacket();

        if(pHandleTftpDataPacket->reachEofReceive)
        {
            pHandleTftpDataPacket->reachEofReceive = 0;
            debug("ok: reachEofReceive the \"while\" of: receive.");
            break;
        }
    }
    close(pSession->localSocket);
    debug("ok: close(localSocket).");

    closeWriteFile();

    return 0;
}

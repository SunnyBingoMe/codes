duldirection is ok,
with block nr,
with request,
correct some structs and inis.

prepare to ack
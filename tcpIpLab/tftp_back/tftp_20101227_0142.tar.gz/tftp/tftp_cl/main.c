#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/timeb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

char * pRemotePort = "69";
char * pLocalPort = "59590";

/*
int sOk = 1;
int dbug = 0;
int dbugOk = 0;
int dDbug = 0;
int dDbugOk = 0;
*/
int sOk = 0;
int dbug = 1;
int dbugOk = 0;
int dDbug = 1;
int dDbugOk = 0;

void say (char * string)
{
    printf("%s\n",string);
}
void sayOk (void * string)
{
    if(sOk)
    {
        say (string);
    }
}
void debug (void * string)
{
    if(dbug)
    {
        say (string);
    }
}
void debugOk (void * string)
{
    if(dbugOk)
    {
        say (string);
    }
}
void dDebug (void * string)
{
    if(dDbug)
    {
        say (string);
    }
}
void dDebugOk (void * string)
{
    if(dDbugOk)
    {
        say (string);
    }
}

char * pDefaultRemoteHost = "127.0.0.1";
char * pDefaultRemoteFilename = "/media/NOW/ET2440_TCPIP/tftp/tftp/rfc867_sr.txt";
char * pDefaultLocalFilename = "/media/NOW/ET2440_TCPIP/tftp/tftp_cl/rfc867_cl.txt";
char cDefaultReadRequest = 'r';
char cDefaultWriteRequest = 'w';
char * pDefaultMode = "octet";
char * pDefaultOpenWriteType = "wb";
char * pDefaultOpenReadType = "rb";

#define maxReadOnce 512
struct aboutReadFile
{
    char * pFilename;
    char * pOpenReadType;
    char aReadBuffer[maxReadOnce];
    int sizeReadUnit;
    int sizeReadData;
    FILE * pReadFile;
};
struct aboutReadFile * pAboutReadFile;
struct aboutWriteFile
{
    char * pFilename;
    char * pOpenWriteType;
    char * pWriteBuffer;
    int sizeWriteUnit;
    int sizeWriteData;
    FILE * pWriteFile;
};
struct aboutWriteFile * pAboutWriteFile;
struct session
{
    char cClientOrServer;
    struct addrinfo getaddrinfoSourceLinkList;
    struct addrinfo * pGetaddrinfoResultLinkList;
    struct addrinfo * pFirstValidGetaddrinfoSourceLinkListSend;
//    struct addrinfo * pFirstValidGetaddrinfoSourceLinkListReceive;
    int localSocket;
    char * pRemoteHost;//name or ip
    char * pRemoteFilename;
    char * pLocalFilename;
    char cReadOrWrite;
    char * pMode;
    struct sockaddr_storage remoteAddressInformation;
    socklen_t sizeRemoteAddressInformation;
    char aIpRemote[INET6_ADDRSTRLEN];
    const char * pTextIpRemote;
};
struct session * pSession;

///pack and unpack
#define udpLoadReceiveMax 516
#define withoutOpcodeMax 514 //blockNr + 512
#define blockDataMax 512
    ///send
struct prepareTftpAckPacket
{
	unsigned short opcode;
	unsigned short blockNr;
};
struct prepareTftpAckPacket * pPrepareTftpAckPacket;
struct prepareTftpRequestPacket
{
	unsigned short opcode;
    char * pFilename;
    int sizeFilename;
    char * pMode;
    int sizeMode;
    int sizeWithoutOpcode;
//    int sizeTftpRequestPacket;
};
struct prepareTftpRequestPacket * pPrepareTftpRequestPacket;
struct prepareTftpDataPacket
{
    int sizeBlockDataToSend;
	unsigned short opcode;
	unsigned short blockNrTftpDataPacket;
    int reachEofSend;
};
struct prepareTftpDataPacket * pPrepareTftpDataPacket;
struct prepareUdpLoad
{
    void * pUdpLoadToSend;
    int sizeUdpLoadToSend;
    int sizeUdpLoadHasSend;//for debug
};
struct prepareUdpLoad * pPrepareUdpLoad;
    ///send end

struct tftpPacket
{
	unsigned short opcodeNetOrder;
	char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpPacket * pTftpPacket;
struct tftpRequestPacket
{
	unsigned short opcodeNetOrder;
    char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpRequestPacket * pTftpRequestPacket;
struct tftpDataPacket
{
	unsigned short opcodeNetOrder;
	unsigned short blockNrNetOrder;
	char aBlockData[blockDataMax];
};
struct tftpDataPacket * pTftpDataPacket;
struct tftpAckPacket
{
	unsigned short opcodeNetOrder;
	unsigned short blockNrNetOrder;
};
struct tftpAckPacket * pTftpAckPacket;

    ///receive
struct handleUdpLoad
{
    char aUdpLoadReceiveBuffer[udpLoadReceiveMax];//void * pUdpLoadHasReceive;
    int sizeUdpLoadHasReceive;
};
struct handleUdpLoad * pHandleUdpLoad;
struct handleTftpPacket
{
    int sizeWithoutOpcode;
    int sizeBlockDataHasReceive;
	unsigned short opcode;
	unsigned short blockNrTftpDataPacket;
};
struct handleTftpPacket * pHandleTftpPacket;
struct handleTftpRequestPacket
{
    char * pFilename;
    int sizeFilename;
    char * pMode;
    int sizeMode;
};
struct handleTftpRequestPacket * pHandleTftpRequestPacket;
struct handleTftpDataPacket
{
    int blockNrTftpDataPacket;
    char * pBlockDataReceive;
    int sizeBlockDataReceive;
    int reachEofReceive;
};
struct handleTftpDataPacket * pHandleTftpDataPacket;
struct handleTftpAckPacket
{
	unsigned short opcode;
	unsigned short blockNr;
};
struct handleTftpAckPacket * pHandleTftpAckPacket;
    ///receive end
///pack and unpack end


void * getBinaryIp(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

char stringTimeStamp[] = "2010-00-00_00:00:00.000_0";
char * timeStamp()
{
    struct timeb tp;
    struct tm ltime;
    ftime(&tp);
    localtime_r(&tp.time,&ltime);
    sprintf(stringTimeStamp,
            "%04d-%02d-%02d_%02d:%02d:%02d.%03d_%d",
            ltime.tm_year+1900,
            ltime.tm_mon+1,
            ltime.tm_mday,
            ltime.tm_hour,
            ltime.tm_min,
            ltime.tm_sec,
            tp.millitm,
            ltime.tm_wday//What day is it.
            );
    stringTimeStamp[23] = '\0';//don't need What day is it.
    return stringTimeStamp;
/*
    char * stringTimeStamp;
    time_t rawtime;
    time ( &rawtime );
    stringTimeStamp = ctime( (time_t*) &rawtime);
    stringTimeStamp[24] = '\0';
    return stringTimeStamp;
*/
}

int initialize(int argc, char *argv[])
{
    debug("ok: in initialize().");
    pSession = malloc(sizeof(struct session));
    memset(pSession, '\0', sizeof(struct session) );
    pSession->cClientOrServer = 'c';

    pAboutWriteFile = malloc(sizeof(struct aboutWriteFile));
    pAboutReadFile = malloc(sizeof(struct aboutReadFile));

    ///send
    pPrepareTftpAckPacket = malloc(sizeof(struct prepareTftpAckPacket));
    pPrepareTftpDataPacket = malloc(sizeof(struct prepareTftpDataPacket));
    pPrepareUdpLoad = malloc(sizeof(struct prepareUdpLoad));
    pPrepareTftpRequestPacket = malloc(sizeof(struct prepareTftpRequestPacket));
    //pPrepareTftpPacket = malloc(sizeof(struct prepareTftpPacket));//no need in both hosts
    if(dbugOk){printf("ok: malloc: sizeof(struct tftpDataPacket):%d.\n",sizeof(struct tftpDataPacket));}
    ///send end

    pTftpRequestPacket = malloc(sizeof(struct tftpRequestPacket));
    pTftpDataPacket = malloc(sizeof(struct tftpDataPacket));
    pTftpPacket = malloc(sizeof(struct tftpPacket));
    pTftpAckPacket = malloc(sizeof(struct tftpAckPacket));

    ///receive
    pHandleUdpLoad = malloc(sizeof(struct handleUdpLoad));
    pHandleTftpPacket = malloc(sizeof(struct handleTftpPacket));
    pHandleTftpDataPacket = malloc(sizeof(struct handleTftpDataPacket));
    pHandleTftpAckPacket = malloc(sizeof(struct handleTftpAckPacket));
    //pHandleTftpRequestPacket = malloc(sizeof(struct handleTftpRequestPacket));//no need in client
    if(dbugOk){printf("ok: malloc: sizeof(struct tftpPacket):%d.\n",sizeof(struct tftpPacket));}
    ///receive end

    memset(&pSession->getaddrinfoSourceLinkList, 0, sizeof pSession->getaddrinfoSourceLinkList);
    pSession->getaddrinfoSourceLinkList.ai_family = AF_UNSPEC;
    pSession->getaddrinfoSourceLinkList.ai_socktype = SOCK_DGRAM;
    //pSession->getaddrinfoSourceLinkList.ai_flags = AI_PASSIVE; //use my IP //code only used in server

    if (argc != 5)
    {
	    printf("OBS! You have not input 1.\"remote host\", 2.\"/remote filename\", 3.\"/local filename\", 4.\"r\" or \"w\". Will use default.\n");
        pSession->pRemoteHost = pDefaultRemoteHost;
        pSession->pRemoteFilename = pDefaultRemoteFilename;
        pSession->pLocalFilename = pDefaultLocalFilename;
        pSession->cReadOrWrite = cDefaultWriteRequest;
        pSession->pMode = pDefaultMode;
        debug("ok: used default.");
    }
    else
    {
        pSession->pRemoteHost = argv[1];
        pSession->pRemoteFilename = argv[2];
        pSession->pLocalFilename = argv[3];
        pSession->cReadOrWrite = *((char*)argv[4]);//'r' for "read from remote"; 'w' for...
        pSession->pMode = pDefaultMode;
    }

    debug("ok: initialize().");
    return 0;
}

int getaddrinfoSend()
{
    int getaddrinfoStatus;
    if ((getaddrinfoStatus = getaddrinfo(pSession->pRemoteHost,// e.g. "www.example.com" or IP
                                          pRemotePort,// e.g. "http" or port number
                                          &pSession->getaddrinfoSourceLinkList,//did not say use locallopp ip
                                          &pSession->pGetaddrinfoResultLinkList//results: a pointer to a linked-list
                                          )
        ) != 0)
    {
        fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(getaddrinfoStatus));
        return 1;
    }

    debug("ok: getaddrinfoSend().");
	return 0;
}

int createSocketSend()
{
    struct addrinfo * pTempAddrinfo;
    for(pTempAddrinfo = pSession->pGetaddrinfoResultLinkList; pTempAddrinfo != NULL; pTempAddrinfo = pTempAddrinfo->ai_next)
    {
        if ((pSession->localSocket = socket(pTempAddrinfo->ai_family,
                                            pTempAddrinfo->ai_socktype,
                                            pTempAddrinfo->ai_protocol
                                            )
            ) == -1
           )
        {
            perror("ERR: socket(), will try next.");
            continue;
        }
        break;
    }
    if (pTempAddrinfo == NULL)
    {
        fprintf(stderr, "ERR: failed to socket().");
        return 2;
    }
    pSession->pFirstValidGetaddrinfoSourceLinkListSend = pTempAddrinfo;

    debug("ok: createSocketSend().");
	return 0;
}

int getaddrinfoReceive()
{
    int getaddrinfoStatus;
    if ((getaddrinfoStatus = getaddrinfo(pSession->pRemoteHost,
                                          pLocalPort,
                                          &pSession->getaddrinfoSourceLinkList,
                                          &pSession->pGetaddrinfoResultLinkList
                                          )
        ) != 0
       )
    {
        fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(getaddrinfoStatus));
        return 1;
    }

    debug("ok: getaddrinfoReceive().");
	return 0;
}

int bindSendSocketAsReceive()
{
    struct addrinfo * pTempAddrinfo;
    for(pTempAddrinfo = pSession->pGetaddrinfoResultLinkList; pTempAddrinfo != NULL; pTempAddrinfo = pTempAddrinfo->ai_next)
    {
        if (bind(pSession->localSocket,
                pTempAddrinfo->ai_addr,
                pTempAddrinfo->ai_addrlen
                ) == -1
            )
        {
            perror("ERR: bind, will try next.");
            continue;
        }

        debug("ok: bind().");
        break;
    }

    if (pTempAddrinfo == NULL)
    {
        fprintf(stderr, "ERR: failed to bind socket\n");
        return 2;
    }
//    pSession->pFirstValidGetaddrinfoSourceLinkListReceive = pTempAddrinfo;

    debug("ok: bindSendSocketAsReceive().");
    return 0;
}

int openWriteFile()
{
    if ( (pAboutWriteFile->pWriteFile = fopen(pAboutWriteFile->pFilename, pAboutWriteFile->pOpenWriteType)) == NULL)
    {
        say("ERR: fopen writeFile.");
        return 1;
    }

    return 0;
}

int packTftpRequestPacket()
{
    if(pSession->cReadOrWrite == 'r')//read request
    {
        pPrepareTftpRequestPacket->opcode = 1;
    }
    else//write request
    {
        pPrepareTftpRequestPacket->opcode = 2;
    }

    pPrepareTftpRequestPacket->pFilename = pSession->pRemoteFilename;
    pPrepareTftpRequestPacket->sizeFilename = strlen(pSession->pRemoteFilename);
    pPrepareTftpRequestPacket->pMode = pSession->pMode;
    pPrepareTftpRequestPacket->sizeMode = strlen(pSession->pMode);
    pPrepareTftpRequestPacket->sizeWithoutOpcode = pPrepareTftpRequestPacket->sizeFilename + pPrepareTftpRequestPacket->sizeMode + 2;

    memset(pTftpRequestPacket, '\0', sizeof(struct tftpRequestPacket));
    pTftpRequestPacket->opcodeNetOrder = htons(pPrepareTftpRequestPacket->opcode);
    memmove(pTftpRequestPacket->aWithoutOpcode, pPrepareTftpRequestPacket->pFilename, pPrepareTftpRequestPacket->sizeFilename);
    memmove(((char*)pTftpRequestPacket->aWithoutOpcode) + pPrepareTftpRequestPacket->sizeFilename + 1, pPrepareTftpRequestPacket->pMode, pPrepareTftpRequestPacket->sizeMode);

    pPrepareUdpLoad->pUdpLoadToSend = (void *)pTftpRequestPacket;
    pPrepareUdpLoad->sizeUdpLoadToSend = 2 + pPrepareTftpRequestPacket->sizeWithoutOpcode;

    debug("ok: packTftpRequestPacket().");
    return 0;
}

int openReadFile()
{
    if ( (pAboutReadFile->pReadFile = fopen(pAboutReadFile->pFilename, pAboutReadFile->pOpenReadType)) == NULL)
    {
        say("ERR: openReadFile(): fopen().");
        exit(1);
    }
    else
    {
        debug("ok: openReadFile().");
    }
    return 0;
}
int closeReadFile()
{
    fclose(pAboutReadFile->pReadFile);
    return 0;
}

int packTftpDataPacket()
{
    int iFread = 0;
    char readTempChar;

    pAboutReadFile->sizeReadUnit = sizeof(char);
    while( fread(&readTempChar,pAboutReadFile->sizeReadUnit,1, pAboutReadFile->pReadFile), !feof(pAboutReadFile->pReadFile) && !ferror(pAboutReadFile->pReadFile) )
    {
        if(dDbugOk){printf("ok: read %c\n", readTempChar);}
        pAboutReadFile->aReadBuffer[iFread] = readTempChar;
        if(dDbugOk){printf("ok: iFread and aReadBuffer[iFread]:%d,%c.\n",iFread,pAboutReadFile->aReadBuffer[iFread]);}
        iFread ++;
        if(iFread == maxReadOnce)
        {
            break;
        }
    }
    if (dDbugOk){printf("ok: while is ok, iFread:%d.\n",iFread);}
    if (feof(pAboutReadFile->pReadFile))
    {
        pPrepareTftpDataPacket->reachEofSend = 1;
        printf("ok: eof.\n");
        if(dbug){printf("ok: in feof(), iFread(last read):%dbytes.\n",iFread);}
//            aReadBuffer[iFread] = '\0';
    }
    if (ferror(pAboutReadFile->pReadFile))
    {
        printf("ERR read file.\n");
    }
    pAboutReadFile->sizeReadData = iFread;

    if (dDbugOk){printf("ok: aReadBuffer:%s.\n",pAboutReadFile->aReadBuffer);}
    if (dDbugOk){printf("ok: aReadBuffer[0]:%s.\n", &(pAboutReadFile->aReadBuffer[0]) );}
    if (dDbugOk){printf("ok: aReadBuffer[1]:%s.\n", &(pAboutReadFile->aReadBuffer[1]) );}

///pack data_packet and re-direct
    pPrepareTftpDataPacket->opcode = 3;//is data packet
    pPrepareTftpDataPacket->sizeBlockDataToSend = pAboutReadFile->sizeReadData;
    pTftpDataPacket->opcodeNetOrder = htons(pPrepareTftpDataPacket->opcode);
    pTftpDataPacket->blockNrNetOrder = htons(pPrepareTftpDataPacket->blockNrTftpDataPacket);
    memmove(pTftpDataPacket->aBlockData, pAboutReadFile->aReadBuffer, pPrepareTftpDataPacket->sizeBlockDataToSend);
    if(dbug){printf("ok: in prepareSend(), blockNrTftpDataPacket:%u.\n",pPrepareTftpDataPacket->blockNrTftpDataPacket);}
    if(dbug){printf("ok: in prepareSend(), sizeBlockDataToSend:%u.\n",pPrepareTftpDataPacket->sizeBlockDataToSend);}

    pPrepareUdpLoad->pUdpLoadToSend = (void *)pTftpDataPacket;
    pPrepareUdpLoad->sizeUdpLoadToSend = 4 + pPrepareTftpDataPacket->sizeBlockDataToSend;
///pack data_packet and re-direct end

    debug("ok: packTftpDataPacket().");
    return 0;
}

int packAndSendUdpPacket()
{
    if ((pPrepareUdpLoad->sizeUdpLoadHasSend = sendto(pSession->localSocket,
                                                   pPrepareUdpLoad->pUdpLoadToSend,
                                                   pPrepareUdpLoad->sizeUdpLoadToSend,
                                                   0,
                                                   pSession->pFirstValidGetaddrinfoSourceLinkListSend->ai_addr,
                                                   pSession->pFirstValidGetaddrinfoSourceLinkListSend->ai_addrlen
                                                  )
        ) == -1)
    {
        perror("ERR: sendto");
        exit(1);
    }
    if(dDbugOk){printf("ok: send: %dbytes, content:%s.\n",pPrepareUdpLoad->sizeUdpLoadHasSend,(char*)pPrepareUdpLoad->pUdpLoadToSend);}
	if(dbug)
	{
        printf("ok: sent %dbytes udpload to %s\n", pPrepareUdpLoad->sizeUdpLoadHasSend, pSession->pRemoteHost);
	}

    printf("ok: sendData().%s.\n",timeStamp());
    return 0;
}

int tftpDataPacketSendOk()
{
    if(dbug){printf("ok: in tftpDataPacketSendOk(), blockNrTftpDataPacket:%u.\n",pPrepareTftpDataPacket->blockNrTftpDataPacket);}
    pPrepareTftpDataPacket->blockNrTftpDataPacket ++;
    return 0;
}

int receiveAndUnpackUdpPacket()
{
    pSession->sizeRemoteAddressInformation = sizeof pSession->remoteAddressInformation;
    if ((pHandleUdpLoad->sizeUdpLoadHasReceive = recvfrom(pSession->localSocket,
                                                        pHandleUdpLoad->aUdpLoadReceiveBuffer,
                                                        udpLoadReceiveMax,//udpLoadReceiveMax-1,////for end of string
                                                        0,
                                                        (struct sockaddr *)&pSession->remoteAddressInformation,
                                                        &pSession->sizeRemoteAddressInformation
                                                        )
         ) == -1)
    {
        perror("recvfrom");
        exit(1);
    }
//    aUdpLoadReceiveBuffer[sizeUdpLoadHasReceive] = '\0';
    if(dbug)
    {
        pSession->pTextIpRemote = inet_ntop(pSession->remoteAddressInformation.ss_family,
                                            getBinaryIp((struct sockaddr *)&pSession->remoteAddressInformation),
                                            pSession->aIpRemote,
                                            sizeof pSession->aIpRemote
                                            );
        printf("ok: got packet from %s\n",pSession->pTextIpRemote);
    }
    if(dDbugOk){printf("ok: recv: %dbytes, %s.\n", pHandleUdpLoad->sizeUdpLoadHasReceive,pHandleUdpLoad->aUdpLoadReceiveBuffer);}
    else{if(dbug)printf("ok: sizeUdpLoadHasReceive:%d.\n",pHandleUdpLoad->sizeUdpLoadHasReceive);}

    printf("ok: receiveAndUnpackUdpPacket().%s.\n",timeStamp());
    return 0;
}

int writeBinaryDataToFile()
{
    debug("ok: in writeBinaryDataToFile().");
    fwrite(pAboutWriteFile->pWriteBuffer, pAboutWriteFile->sizeWriteUnit, pAboutWriteFile->sizeWriteData, pAboutWriteFile->pWriteFile);

    say("ok: writeBinaryDataToFile().");
    return 0;
}
int unpackTftpDataPacket()
{
    debug("ok: packet is data_packet.");
    pTftpDataPacket = (struct tftpDataPacket *) pTftpPacket;
    pHandleTftpDataPacket->blockNrTftpDataPacket = ntohs(pTftpDataPacket->blockNrNetOrder);
    pHandleTftpDataPacket->sizeBlockDataReceive = pHandleTftpPacket->sizeWithoutOpcode - 2;
    pHandleTftpDataPacket->pBlockDataReceive = pTftpDataPacket->aBlockData;
    if(pHandleTftpDataPacket->sizeBlockDataReceive < blockDataMax)
    {
        pHandleTftpDataPacket->reachEofReceive = 1;
    }
    if(dbug){printf("ok: pHandleTftpDataPacket->blockNrTftpDataPacket:%d.\n",pHandleTftpDataPacket->blockNrTftpDataPacket);}

    pAboutWriteFile->pWriteBuffer = pHandleTftpDataPacket->pBlockDataReceive;
    pAboutWriteFile->sizeWriteData = pHandleTftpDataPacket->sizeBlockDataReceive;
    pAboutWriteFile->sizeWriteUnit = sizeof(char);
    if(dbug){printf("ok: sizeWriteData = sizeBlockDataReceive:%d.\n",pAboutWriteFile->sizeWriteData);}
    writeBinaryDataToFile();

    return 0;
}

int unpackTftpPacket()
{
    pTftpPacket = (struct tftpPacket*) pHandleUdpLoad->aUdpLoadReceiveBuffer;

    pHandleTftpDataPacket->reachEofReceive = 0;

    ///unpack and re-direct
    pHandleTftpPacket->sizeWithoutOpcode = pHandleUdpLoad->sizeUdpLoadHasReceive - 2;
    pHandleTftpPacket->opcode = ntohs(pTftpPacket->opcodeNetOrder);
    ///if data, then tftpPacket => dataPacket
    if(pHandleTftpPacket->opcode == 3)
    {
        unpackTftpDataPacket();
    }
    ///unpack and re-direct end

    debug("ok: unpackTftpPacket().");
    return 0;
}

int closeWriteFile()
{
    fclose(pAboutWriteFile->pWriteFile);
    return 0;
}

int openWriteFileAndReceiveAndSaveDataAndClose()
{
    pAboutWriteFile->pFilename = pSession->pLocalFilename;
    pAboutWriteFile->pOpenWriteType = pDefaultOpenWriteType;
    openWriteFile();

    while(1) ///the "while" of: receive the data of remote file and write to local file
    {
        debug("\nok: \"while\": receive and write.start.");
        receiveAndUnpackUdpPacket();

        unpackTftpPacket();

        if(pHandleTftpDataPacket->reachEofReceive)
        {
            pHandleTftpDataPacket->reachEofReceive = 0;
            debug("ok: reachEofReceive the \"while\" of: receive.");
            break;
        }
    }
    closeWriteFile();

    debug("ok: openWriteFileAndReceiveAndSaveDataAndClose().end.");
    return 0;
}

int sendTheRequestFile()//code from server
{
    pAboutReadFile->pFilename = pSession->pLocalFilename;
    pAboutReadFile->pOpenReadType = pDefaultOpenReadType;
    openReadFile();

    pPrepareTftpDataPacket->blockNrTftpDataPacket = 1;
    pPrepareTftpDataPacket->reachEofSend = 0;

    while(1) ///transfer the data of the file
    {
        debug("ok: while: transfer the data of the file.start.");
        packTftpDataPacket();

        packAndSendUdpPacket();

//            sleep(1);
        tftpDataPacketSendOk();

        if(pPrepareTftpDataPacket->reachEofSend)
        {
            debug("ok: reach eof.");
            break;
        }

        say("");
    }

    closeReadFile();
    pPrepareTftpDataPacket->blockNrTftpDataPacket = 1;
    pPrepareTftpDataPacket->reachEofSend = 0;

    debug("ok: sendTheRequestFile()");
    return 0;
}

int main(int argc, char *argv[])
{
    initialize(argc, argv);

    getaddrinfoSend();
    createSocketSend();

    getaddrinfoReceive();
    bindSendSocketAsReceive();
    freeaddrinfo(pSession->pGetaddrinfoResultLinkList);

    packTftpRequestPacket();
    packAndSendUdpPacket();

    if(pSession->cReadOrWrite == 'r')//read request
    {
        openWriteFileAndReceiveAndSaveDataAndClose();
    }
    else//write request
    {
        sendTheRequestFile();
    }

    close(pSession->localSocket);
    debug("ok: close(localSocket).");

    if(dbug){printf("ok: %s.\n",timeStamp());}
    return 0;
}

added timer.

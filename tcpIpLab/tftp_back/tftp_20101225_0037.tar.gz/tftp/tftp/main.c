#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define MYPORT "69"    // the port users will be connecting to
#define dataReceiveMax 600

/*
//#define DEBUG
int sOk = 1;
int dbug = 0;
int dbugOk = 0;
int dDbug = 0;
int dDbugOk = 0;
*/
#define DEBUG
int sOk = 0;
int dbug = 1;
int dbugOk = 0;
int dDbug = 1;
int dDbugOk = 0;

void say (char * string)
{
    printf("%s\n",string);
}
void sayOk (void * string)
{
    if(sOk)
    {
        say (string);
    }
}
void debug (void * string)
{
    if(dbug)
    {
        say (string);
    }
}
void debugOk (void * string)
{
    if(dbugOk)
    {
        say (string);
    }
}
void dDebug (void * string)
{
    if(dDbug)
    {
        say (string);
    }
}
void dDebugOk (void * string)
{
    if(dDbugOk)
    {
        say (string);
    }
}


int localSocket;
struct addrinfo hints, *servinfo, *p;
int rv;
int sizeDataReceive;
struct sockaddr_storage remoteAddressInformation;
char bufferDataReceive[dataReceiveMax];
socklen_t sizeRemoteAddressInformation;
char ipRemote[INET6_ADDRSTRLEN];
//char * pUdpLoadToSend;

///read and write file
#define maxReadOnce 512
char * pReadFilePath = "/media/NOW/ET2440_TCPIP/tftp/tftp/rfc867_sr.txt";
//char * pReadFilePath = "/media/NOW/ET2440_TCPIP/network_c/server_info.txt";
char * pOpenReadType = "rb";
FILE * pReadFile;
char readTempChar;
char aReadBuffer[maxReadOnce];
int  sizeReadBuffer;
///read and write file end

///pack and unpack struct
struct prepareTftpDataPacket
{
    int sizeBlockDataToSend;
	unsigned short opcode;
	unsigned short blockNrTftpDataPacket;
};
struct prepareTftpDataPacket * pPrepareTftpDataPacket;

struct tftpDataPacket
{
	unsigned short opcodeNetOrder;
	unsigned short blockNrNetOrder;
	char aBlockData[512];
};
struct tftpDataPacket * pTftpDataPacket;

///need use
/// need change
struct prepareTftpPacket
{
    int sizeBlockToSend;
	unsigned short opcode;
	unsigned short blockNrTftpPacket;
};
struct prepareTftpPacket * pPrepareTftpPacket;
/// need change end


#define withoutOpcodeMax 514 //blockNr + 512
struct tftpPacket
{
	unsigned short opcodeNetOrder;
	char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpPacket * pTftpPacket;

///need use end


struct prepareUdpLoad
{
    void * pUdpLoadToSend;
    int sizeUdpLoadToSend;
    int sizeUdpLoadHasSend;//for debug
};
struct prepareUdpLoad * pPrepareUdpLoad;


///pack and unpack struct end


void *getBinaryIp(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int printTimeStamp()
{
    time_t rawtime;
    time ( &rawtime );
    printf("ok: %s\n",ctime( (time_t*) &rawtime));
    return 0;
}

int initializeAndGetaddrinfoLocal()
{
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE; // use my IP

    pPrepareTftpDataPacket = malloc(sizeof(struct prepareTftpDataPacket));
    pTftpDataPacket = malloc(sizeof(struct tftpDataPacket));
    pPrepareTftpPacket = malloc(sizeof(struct prepareTftpPacket));
    pTftpPacket = malloc(sizeof(struct tftpPacket));
    pPrepareUdpLoad = malloc(sizeof(struct prepareUdpLoad));
    if(dbugOk){printf("ok: malloc: sizeof(struct tftpDataPacket):%d.\n",sizeof(struct tftpDataPacket));}

    if ((rv = getaddrinfo(NULL, MYPORT, &hints, &servinfo)) != 0)
    {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }

    debug("ok: initializeAndGetaddrinfoLocal");

    return 0;
}

int tryCreateAndBind()
{
    for(p = servinfo; p != NULL; p = p->ai_next)
    {
        if ((localSocket = socket(p->ai_family,
                            p->ai_socktype,
                            p->ai_protocol
                            )
            ) == -1
           )
        {
            perror("server: socket");
            continue;
        }
        else
        {
            debug("ok: succeed create socket.");
        }

        if (bind(localSocket,
                p->ai_addr,
                p->ai_addrlen
                ) == -1
            )
        {
            close(localSocket);
            perror("server: bind");
            continue;
        }
        break;
    }

    if (p == NULL)
    {
        fprintf(stderr, "server: failed to bind socket, p == NULL\n");
        return 2;
    }
    else
    {
        debug("ok: succeed bind.");
    }

    return 0;
}

int receiveDataAndRemoteInformation()
{
    if ((sizeDataReceive = recvfrom(localSocket,
                            bufferDataReceive,
                            dataReceiveMax-1,
                            0,
                            (struct sockaddr *)&remoteAddressInformation,
                            &sizeRemoteAddressInformation
                            )
         ) == -1
        )
    {
        perror("recvfrom");
        exit(1);
    }
    printf("ok: server: got request from %s\n",
            inet_ntop(remoteAddressInformation.ss_family,
                      getBinaryIp((struct sockaddr *)&remoteAddressInformation),
                      ipRemote,
                      sizeof ipRemote
                      )
          );
    if(dbug)
    {
        bufferDataReceive[sizeDataReceive] = '\0';
    }
    printf("ok: recv: %dbytes, %s.\n", sizeDataReceive,bufferDataReceive);

    return 0;
}

int openReadFile()
{
    if ( (pReadFile = fopen(pReadFilePath, pOpenReadType)) == NULL)
    {
        say("ERR: fopen readFile.");
        exit(1);
    }
    else
    {
        debug("ok: openReadFile().");
    }
    return 0;
}

int prepareSend()
{
    int iFread = 0;
    int reachEofSend = 0;

    while( fread(&readTempChar, sizeof(char),1, pReadFile), !feof(pReadFile) && !ferror(pReadFile) )
    {
        if(dDbugOk){printf("ok: read %c\n", readTempChar);}
        aReadBuffer[iFread] = readTempChar;
        if(dDbugOk){printf("ok: iFread and aReadBuffer[iFread]:%d,%c.\n",iFread,aReadBuffer[iFread]);}
        iFread ++;
        if(iFread == maxReadOnce)
        {
            break;
        }
    }
    if (dDbugOk){printf("ok: while is ok, iFread:%d.\n",iFread);}
    if (feof(pReadFile))
    {
        reachEofSend = 1;
        printf("ok: eof.\n");
        if(dbug)
        {
            if (dDbugOk){printf("ok: in feof(), iFread:%d.\n",iFread);}
//            aReadBuffer[iFread] = '\0';
        }
    }
    if (ferror(pReadFile))
    {
        printf("ERR read file.\n");
    }

    if (dDbugOk){printf("ok: aReadBuffer:%s.\n",aReadBuffer);}
    if (dDbugOk){printf("ok: aReadBuffer[0]:%s.\n",&aReadBuffer[0]);}
    if (dDbugOk){printf("ok: aReadBuffer[1]:%s.\n",&aReadBuffer[1]);}

///pack data packet
    pPrepareTftpDataPacket->sizeBlockDataToSend = iFread;
    pPrepareTftpDataPacket->opcode = 3;//is data packet
    pTftpDataPacket->opcodeNetOrder = htons(pPrepareTftpDataPacket->opcode);
    pTftpDataPacket->blockNrNetOrder = htons(pPrepareTftpDataPacket->blockNrTftpDataPacket);
    memmove(pTftpDataPacket->aBlockData, aReadBuffer, pPrepareTftpDataPacket->sizeBlockDataToSend);
///pack data packet end

///re-direct
    pPrepareUdpLoad->pUdpLoadToSend = (void *)pTftpDataPacket;
    pPrepareUdpLoad->sizeUdpLoadToSend = 4 + pPrepareTftpDataPacket->sizeBlockDataToSend;
///re-direct end

    debug("ok: prepareSend().");
    return reachEofSend;
}

int sendData()
{
    if ((pPrepareUdpLoad->sizeUdpLoadHasSend = sendto(localSocket,
                                                       pPrepareUdpLoad->pUdpLoadToSend,
                                                       pPrepareUdpLoad->sizeUdpLoadToSend,
                                                       0,
                                                       (struct sockaddr *)&remoteAddressInformation,
                                                       sizeof (struct sockaddr)
                                                      )
         ) == -1
        )
    {
        perror("talker: sendto");
        exit(1);
    }

    if(dbug)
    {
        printf("ok: strlen is %dbytes.\n",pPrepareUdpLoad->sizeUdpLoadToSend);
        printf("ok: sent to %s.\n",
               inet_ntop(remoteAddressInformation.ss_family,
                         getBinaryIp((struct sockaddr *)&remoteAddressInformation),
                         ipRemote,
                         sizeof ipRemote
                        )
              );

    }
    if(dDbugOk){printf("ok: send: %dbytes, %s.\n",pPrepareUdpLoad->sizeUdpLoadHasSend,(char*)pPrepareUdpLoad->pUdpLoadToSend);}
    else{if(dbug){printf("ok: send: %dbytes.\n",pPrepareUdpLoad->sizeUdpLoadHasSend);}}
    return 0;
}

int tftpDataPacketSendOk()
{
    if(dbug){printf("ok: in tftpDataPacketSendOk(), blockNrTftpDataPacket:%u.",pPrepareTftpDataPacket->blockNrTftpDataPacket);}
    pPrepareTftpDataPacket->blockNrTftpDataPacket ++;
    return 0;
}

int closeReadFile()
{
    fclose(pReadFile);
    return 0;
}

int mainWhile()
{
    int reachEofSend = 0;
    while(1)
    {
        printf("ok: server: waiting request ...\n\n");

        sizeRemoteAddressInformation = sizeof remoteAddressInformation;

        receiveDataAndRemoteInformation();

        openReadFile();
        pPrepareTftpDataPacket->blockNrTftpDataPacket = 1;

        while(1) ///transfer the data of the file
        {
            debug("ok: in while: transfer the data of the file.");
            reachEofSend = prepareSend();

            sendData();
            printTimeStamp();

            if(reachEofSend)
            {
                reachEofSend = 0;
                break;
            }
//            sleep(1);
            tftpDataPacketSendOk();
        }

        closeReadFile();
        pPrepareTftpDataPacket->blockNrTftpDataPacket = 1;
    }
    return 0;
}

int main(void)
{
    initializeAndGetaddrinfoLocal();

    tryCreateAndBind();
    freeaddrinfo(servinfo);

    mainWhile();

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define SERVERPORT "69"    // the port users will be connecting to
#define MYPORT "59590"

/*
//#define DEBUG
int sOk = 1;
int dbug = 0;
int dbugOk = 0;
int dDbug = 0;
int dDbugOk = 0;
*/
#define DEBUG
int sOk = 0;
int dbug = 1;
int dbugOk = 0;
int dDbug = 1;
int dDbugOk = 0;

void say (char * string)
{
    printf("%s\n",string);
}
void sayOk (void * string)
{
    if(sOk)
    {
        say (string);
    }
}
void debug (void * string)
{
    if(dbug)
    {
        say (string);
    }
}
void debugOk (void * string)
{
    if(dbugOk)
    {
        say (string);
    }
}
void dDebug (void * string)
{
    if(dDbug)
    {
        say (string);
    }
}
void dDebugOk (void * string)
{
    if(dDbugOk)
    {
        say (string);
    }
}


int localSocket;
struct addrinfo hints, *servinfo, *p, *pp;
int rv;
int sizeUdpLoadHasSend, sizeUdpLoadHasReceive;

socklen_t sizeRemoteAddressInformation;
struct sockaddr_storage remoteAddressInformation;
char aIpRemote[INET6_ADDRSTRLEN];

///read and write file
char * pWriteFilePath = "/media/NOW/ET2440_TCPIP/tftp/tftp_cl/rfc867_cl.txt";
//char * pWriteFilePath = "/media/NOW/ET2440_TCPIP/network_c/client_info.txt";
char * pOpenWriteType = "wb";
FILE * pWriteFile;
char * pWriteBuffer;
int sizeWriteBuffer;
///read and write file end

///pack and unpack
#define udpLoadReceiveMax 600
struct handleUdpLoad
{
    char aUdpLoadReceiveBuffer[udpLoadReceiveMax];//void * pUdpLoadHasReceive;
    int sizeUdpLoadHasReceive;
};
struct handleUdpLoad * pHandleUdpLoad;

#define withoutOpcodeMax 514 //blockNr + 512
struct tftpPacket
{
	unsigned short opcodeNetOrder;
	char aWithoutOpcode[withoutOpcodeMax];
};
struct tftpPacket * pTftpPacket;

struct handleTftpPacket
{
    int sizeWithoutOpcode;
    int sizeBlockDataHasReceive;
	unsigned short opcode;
	unsigned short blockNrTftpDataPacket;
};
struct handleTftpPacket * pHandleTftpPacket;

#define blockDataReceiveMax 512
struct tftpDataPacket
{
	unsigned short opcodeNetOrder;
	unsigned short blockNrNetOrder;
	char aBlockData[blockDataReceiveMax];
};
struct tftpDataPacket * pTftpDataPacket;

struct handleTftpDataPacket
{
    int blockNrTftpDataPacket;
    char * pBlockDataReceive;
    int sizeBlockDataReceive;
};
struct handleTftpDataPacket * pHandleTftpDataPacket;

struct tftpAckPacket
{
};
struct tftpAckPacket * pTftpAckPacket;
//etc.

///pack and unpack end


void *getBinaryIp(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET)
    {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int printTimeStamp()
{
    time_t rawtime;
    time ( &rawtime );
    printf("ok: %s\n",ctime( (time_t*) &rawtime));
    return 0;
}

int handleArgument(int argc, char *argv[])
{
    if (argc != 3)
    {
	    printf("OBS! no server addr, use default.\n");
        argv[1]="127.0.0.1";
        argv[2]="~Thisis the default ANY massage.";
    }
    return 0;
}

int initialize()
{
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;

    pHandleUdpLoad = malloc(sizeof(struct handleUdpLoad));
    pTftpPacket = malloc(sizeof(struct tftpPacket));
    pHandleTftpPacket = malloc(sizeof(struct handleTftpPacket));
    pTftpDataPacket = malloc(sizeof(struct tftpDataPacket));
    pHandleTftpDataPacket = malloc(sizeof(struct handleTftpDataPacket));
    pTftpAckPacket = malloc(sizeof(struct tftpAckPacket));
    if(dbugOk){printf("ok: malloc: sizeof(struct tftpPacket):%d.\n",sizeof(struct tftpPacket));}

    debug("ok: ini.");

    return 0;
}

int getaddrinfoSend(char *argv[])
{
    if ((rv = getaddrinfo(argv[1],
                          SERVERPORT,
                          &hints,
                          &servinfo
                          )
        ) != 0
       )
    {
        fprintf(stderr, "ERR: getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }
	else
	{
        debug("ok: getaddrinfo()_SERVERPORT.");
	}
	return 0;
}

int createSocketSend()
{
    // loop through all the results and make a socket
    for(p = servinfo; p != NULL; p = p->ai_next)
    {
        if ((localSocket = socket(p->ai_family,
                                    p->ai_socktype,
                                    p->ai_protocol
                                 )
            ) == -1
           ) {
            perror("ERR: socket().");
            continue;
        }
        break;
    }
    if (p == NULL)
    {
        fprintf(stderr, "ERR: failed to socket().");
        return 2;
    }
	else
	{
        debug("ok: socket().");
	}

	return 0;
}

int getaddrinfoReceive(char *argv[])
{
    if ((rv = getaddrinfo(argv[1],
                          MYPORT,
                          &hints,
                          &servinfo
                          )
        ) != 0
       )
    {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }
	else
	{
        debug("ok: getaddrinfo()_MYPORT.");
	}

	return 0;
}

int bindSendSocketAsReceive()
{
    for(pp = servinfo; pp != NULL; pp = pp->ai_next)
    {
        if (bind(localSocket,
                pp->ai_addr,
                pp->ai_addrlen
                ) == -1
            )
        {
            perror("server: bind");
            continue;
        }
        break;
    }
    if (pp == NULL)
    {
        fprintf(stderr, "ERR: failed to bind socket\n");
        return 2;
    }
    else
    {
        debug("ok: bind()\n");
    }

    return 0;
}

int openWriteFile()
{
    if ( (pWriteFile = fopen(pWriteFilePath, pOpenWriteType)) == NULL)
    {
        say("ERR: fopen writeFile.");
        return 1;
    }

    return 0;
}

int sendData(char *argv[])
{
    if ((sizeUdpLoadHasSend = sendto(localSocket,
                                   argv[2],
                                   strlen(argv[2]),
                                   0,
                                   p->ai_addr,
                                   p->ai_addrlen
                                  )
        ) == -1
       )
    {
        perror("ERR: sendto");
        exit(1);
    }
    printf("ok: send: %dbytes, %s.\n",sizeUdpLoadHasSend,argv[2]);
	if(dbug)
	{
        printf("ok: sent packet to %s\n", argv[1]);
        printf("ok: client: waiting packet ...\n");
	}

	return 0;
}

int receiveDataAndRemoteInformation()
{
    if ((sizeUdpLoadHasReceive = recvfrom(localSocket,
                                        pHandleUdpLoad->aUdpLoadReceiveBuffer,
                                        udpLoadReceiveMax,//udpLoadReceiveMax-1,////for end of string
                                        0,
                                        (struct sockaddr *)&remoteAddressInformation,
                                        &sizeRemoteAddressInformation
                                        )
         ) == -1
        )
    {
        perror("recvfrom");
        exit(1);
    }
//    aUdpLoadReceiveBuffer[sizeUdpLoadHasReceive] = '\0';
    if(dbug)
    {
        printf("ok: got packet from %s\n",
                inet_ntop(remoteAddressInformation.ss_family,
                        getBinaryIp((struct sockaddr *)&remoteAddressInformation),
                        aIpRemote,
                        sizeof aIpRemote
                        )
              );
    }
    if(dDbugOk){printf("ok: recv: %dbytes, %s.\n", sizeUdpLoadHasReceive,pHandleUdpLoad->aUdpLoadReceiveBuffer);}
    else{if(dbug)printf("ok: sizeUdpLoadHasReceive:%d.\n",sizeUdpLoadHasReceive);}

    return 0;
}

int prepareWrite()
{
    int reachEofReceive = 0;

///unpack and re-direct
    pTftpPacket = (struct tftpPacket*) pHandleUdpLoad->aUdpLoadReceiveBuffer;
    pHandleTftpPacket->sizeWithoutOpcode = sizeUdpLoadHasReceive - 2;
    pHandleTftpPacket->opcode = ntohs(pTftpPacket->opcodeNetOrder);

    if(pHandleTftpPacket->opcode == 3)///tftpPacket => dataPacket
    {
        debug("ok: packet is data_packet.");
        pTftpDataPacket = (struct tftpDataPacket *) pTftpPacket;
        pHandleTftpDataPacket->blockNrTftpDataPacket = ntohs(pTftpDataPacket->blockNrNetOrder);
        pHandleTftpDataPacket->sizeBlockDataReceive = pHandleTftpPacket->sizeWithoutOpcode - 2;
        pHandleTftpDataPacket->pBlockDataReceive = pTftpDataPacket->aBlockData;
        if(pHandleTftpDataPacket->sizeBlockDataReceive < blockDataReceiveMax)
        {
            reachEofReceive = 1;
        }

        pWriteBuffer = pHandleTftpDataPacket->pBlockDataReceive;
        if (dbug){printf("ok: prepareWrite(): size of \"aUdpLoadReceiveBuffer\":%d.\n",sizeof(pHandleUdpLoad->aUdpLoadReceiveBuffer) );}
        if (dbug){printf("ok: prepareWrite(): size of \"pWriteBuffer\":%d.\n",sizeWriteBuffer = sizeof(pWriteBuffer) );}
        sizeWriteBuffer = pHandleTftpDataPacket->sizeBlockDataReceive;
        if(dbug){printf("ok: sizeWriteBuffer = pHandleTftpDataPacket->sizeBlockDataReceive:%d.\n",sizeWriteBuffer);}
        debug("ok: prepareWrite().");
    }
///unpack and re-direct end

    return reachEofReceive;
}

int writeDataToFile()
{
    debug("ok: in writeDataToFile().");
//    sizeWriteBuffer = sizeReadBuffer;
    fwrite(pWriteBuffer, sizeof(char), sizeWriteBuffer, pWriteFile);

    say("ok: writeDataToFile().");
    return 0;
}

int closeWriteFile()
{
    fclose(pWriteFile);
    return 0;
}

int main(int argc, char *argv[])
{
    int reachEofReceive = 0;

    handleArgument(argc, argv);

    initialize();

    getaddrinfoSend(argv);

    createSocketSend();

    getaddrinfoReceive(argv);

    bindSendSocketAsReceive();
    freeaddrinfo(servinfo);

    openWriteFile();

    sendData(argv);

    sizeRemoteAddressInformation = sizeof remoteAddressInformation;

    while(1) ///the "while" of: receive the data of remote file and write to local file
    {
        receiveDataAndRemoteInformation();

        reachEofReceive = prepareWrite();

        writeDataToFile();
        printTimeStamp();

        if(reachEofReceive)
        {
            reachEofReceive = 0;
            debug("ok: reachEofReceive the \"while\" of: receive.");
            break;
        }
    }
    close(localSocket);
    debug("ok: close(localSocket).");

    closeWriteFile();

    return 0;
}

default file, default from server to client.

no flow control. 
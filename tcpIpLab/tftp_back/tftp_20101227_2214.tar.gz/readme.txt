complete wrq's check of opcode and blockNr.

without rrq's check.
without err control.
without flow control.